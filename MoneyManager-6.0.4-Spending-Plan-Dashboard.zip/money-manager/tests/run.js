/* Logic + rendering tests. Loads www/app.js in a sandbox with a fake DOM, no browser needed.  Run: node tests/run.js */
const vm = require('vm'), fs = require('fs'), path = require('path'), assert = require('assert');
const code = fs.readFileSync(path.join(__dirname, '..', 'www', 'app.js'), 'utf8');

function makeEnv() {
  const store = new Map(), els = {}, errors = [];
  const el = () => ({ innerHTML: '', textContent: '', value: '', style: {}, classList: { add() {}, remove() {}, contains: () => false }, appendChild() {}, remove() {}, click() {}, setAttribute() {} });
  const doc = { querySelector: s => els[s] || (els[s] = el()), getElementById: () => null, addEventListener() {}, createElement: () => el(), body: el(), hidden: false };
  const ctx = {
    document: doc, localStorage: { getItem: k => store.has(k) ? store.get(k) : null, setItem: (k, v) => store.set(k, String(v)), removeItem: k => store.delete(k) },
    navigator: { userAgent: 'node', maxTouchPoints: 0, platform: 'x' }, location: { protocol: 'https:' }, matchMedia: () => ({ matches: false }),
    crypto: require('crypto').webcrypto, TextEncoder, URL, Blob, console, setTimeout, clearTimeout, Date, Math, JSON, Promise,
    confirm: () => true, scrollTo() {}, atob, btoa, Request, File: class {}, addEventListener() {}, Capacitor: undefined,
  };
  ctx.window = ctx; ctx.self = ctx;
  vm.createContext(ctx);
  vm.runInContext(code, ctx);
  return { ctx, ev: c => vm.runInContext(c, ctx), els, store };
}

let pass = 0, fail = 0;
async function t(name, fn) { try { await fn(); pass++; console.log('  ok   ' + name); } catch (e) { fail++; console.log('  FAIL ' + name + '\n       ' + (e && e.message)); } }
const J = x => JSON.stringify(x);

(async () => {
  console.log('Money Manager tests');

  await t('boots and renders every tab without errors', async () => {
    const { ev, els } = makeEnv();
    for (const tab of ['home', 'act', 'bud', 'goal', 'ins', 'acc', 'set']) { ev(`tab='${tab}';render()`); assert(els['#main'].innerHTML.length > 50, tab + ' rendered empty'); }
  });

  await t('monthly insights renders a six-month report without changing saved data', async () => {
    const { ev } = makeEnv();
    await ev(`api('inc_save',{date:'2026-10-05',month:'2026-10',amount:1000,cat:'Salary'})`);
    await ev(`api('tx_save',{date:'2026-10-06',type:'expense',amount:125,cat:'Food',note:'Groceries'})`);
    const before = ev(`JSON.stringify(DB)`);
    ev(`M='2026-10';DB=readDB();S=state(S.account,S.plan);tab='ins';render()`);
    assert(ev(`$('#main').innerHTML.includes('Monthly insights')`));
    assert(ev(`$('#main').innerHTML.includes('Groceries')`) === false, 'report should summarize categories, not expose transaction notes');
    assert.strictEqual(ev(`JSON.stringify(DB)`), before, 'rendering insights must not mutate saved data');
  });

  await t('activity search supports amount, category, and all-month browsing', async () => {
    const { ev } = makeEnv();
    await ev(`api('tx_save',{date:'2026-10-06',type:'expense',amount:12.5,cat:'Food',note:'Lunch'})`);
    await ev(`api('tx_save',{date:'2026-09-06',type:'expense',amount:42,cat:'Transport',note:'Bus pass'})`);
    ev(`M='2026-10';DB=readDB();S=state(S.account,S.plan);tab='act';flt='all';q='';catflt='all';allMonths=false`);
    assert(ev(`lst().includes('Lunch')`), 'current month transaction should appear');
    assert(!ev(`lst().includes('Bus pass')`), 'older transaction is hidden in current-month mode');
    ev(`q='12.50'`); assert(ev(`lst().includes('Lunch')`), 'amount should be searchable');
    ev(`q='';catflt='Transport'`); assert(!ev(`lst().includes('Lunch')`) && !ev(`lst().includes('Bus pass')`), 'category filter should apply to the current month');
    ev(`catflt='all';allMonths=true`); assert(ev(`lst().includes('Bus pass')`), 'all-month mode should include older transactions');
    ev(`catflt='Transport'`); assert(ev(`lst().includes('Bus pass')`) && !ev(`lst().includes('Lunch')`), 'category filter should work across all months');
  });

  await t('income only counts for the month it is assigned to', async () => {
    const { ev } = makeEnv();
    await ev(`api('inc_save',{date:'2026-10-05',month:'2026-10',amount:1000,cat:'Salary'})`);
    await ev(`api('inc_save',{date:'2026-10-28',month:'2026-11',amount:500,cat:'Gift'})`);
    assert.strictEqual(ev(`flow(DB,1,'2026-10').bal`), 1000);
    assert.strictEqual(ev(`flow(DB,1,'2026-11').bal`), 500);
    assert.strictEqual(ev(`flow(DB,1,'2026-12').bal`), 0);
    assert.strictEqual(ev(`flow(DB,1,'2026-09').bal`), 0);
  });

  await t('income month defaults to the date when none is given', async () => {
    const { ev } = makeEnv();
    await ev(`api('inc_save',{date:'2026-03-15',amount:50,cat:'Other'})`);
    assert.strictEqual(ev(`DB.inc[0].month`), '2026-03');
  });

  await t('expenses only reduce the month they are dated in', async () => {
    const { ev } = makeEnv();
    await ev(`api('inc_save',{date:'2026-10-01',month:'2026-10',amount:1000,cat:'Salary'})`);
    await ev(`api('inc_save',{date:'2026-11-01',month:'2026-11',amount:800,cat:'Salary'})`);
    await ev(`api('tx_save',{date:'2026-10-10',type:'expense',amount:300,cat:'Food'})`);
    assert.strictEqual(ev(`flow(DB,1,'2026-10').bal`), 700);
    assert.strictEqual(ev(`flow(DB,1,'2026-11').bal`), 800);
  });

  await t('carry-over mode rolls leftovers (and overspend) forward', async () => {
    const { ev } = makeEnv();
    await ev(`api('inc_save',{date:'2026-10-01',month:'2026-10',amount:1000,cat:'Salary'})`);
    await ev(`api('inc_save',{date:'2026-11-01',month:'2026-11',amount:500,cat:'Salary'})`);
    await ev(`api('tx_save',{date:'2026-10-10',type:'expense',amount:300,cat:'Food'})`);
    await ev(`api('carry_set',{v:true})`);
    assert.strictEqual(ev(`flow(DB,1,'2026-11').bal`), 1200);
    assert.strictEqual(ev(`flow(DB,1,'2026-11').carried`), 700);
    assert.strictEqual(ev(`flow(DB,1,'2026-09').bal`), 0);
    await ev(`api('tx_save',{date:'2026-12-02',type:'expense',amount:1500,cat:'Bills'})`);
    assert.strictEqual(ev(`flow(DB,1,'2026-12').bal`), -300);
    assert.strictEqual(ev(`flow(DB,1,'2027-01').carried`), -300);
  });

  await t('pocket money is ignored and never added to account balances', async () => {
    const { ev } = makeEnv();
    await ev(`api('acc_save',{id:1,name:'Main',icon:'🏦',cur:'$',pocket:250,pocketMonth:'2026-06'})`);
    assert.strictEqual(ev(`flow(DB,1,'2026-06').bal`), 0);
    assert.strictEqual(ev(`flow(DB,1,'2026-07').bal`), 0);
  });

  await t('transfers move money in the month of the transfer', async () => {
    const { ev } = makeEnv();
    await ev(`api('acc_save',{name:'Savings',icon:'💵',cur:'$',pocket:0,pocketMonth:'2026-10'})`);
    await ev(`api('inc_save',{date:'2026-10-01',month:'2026-10',amount:400,cat:'Salary'})`); // goes into Savings (now active)
    ev(`S.account=1;S.plan=0`);await ev(`api('nav')`);
    await ev(`api('inc_save',{date:'2026-10-01',month:'2026-10',amount:1000,cat:'Salary'})`);
    await ev(`api('tx_save',{date:'2026-10-20',type:'transfer',amount:250,cat:'Transfer',to:2})`);
    assert.strictEqual(ev(`flow(DB,1,'2026-10').bal`), 750);
    assert.strictEqual(ev(`flow(DB,2,'2026-10').bal`), 650);
    assert.strictEqual(ev(`flow(DB,2,'2026-11').bal`), 0);
  });

  await t('legacy data gets a month for income and pocket money', async () => {
    const { ev, store } = makeEnv();
    store.set('mm_db', J({ v: 2, n: { acc: 2, plan: 2, tx: 2, inc: 2, goal: 1 }, accounts: [{ id: 1, name: 'Old', icon: '🏦', cur: '$', pocket: 100 }], plans: [{ id: 1, account: 1, name: 'General', icon: '🏠' }],
      tx: [{ id: 1, plan: 1, date: '2026-02-03', type: 'expense', amount: 5, cat: 'Food', to: null, note: '' }], inc: [{ id: 1, account: 1, date: '2026-02-01', amount: 900, cat: 'Salary', note: '' }], budgets: [], goals: [], pin: null, last: { acc: 1, plan: 1 } }));
    ev(`DB=readDB()`);
    assert.strictEqual(ev(`DB.inc[0].month`), '2026-02');
    assert.strictEqual(ev(`DB.accounts[0].pocketMonth`), '2026-02');
    assert.strictEqual(ev(`DB.carry`), false);
  });

  await t('rounding never shows -$0.00 and sums stay exact', async () => {
    const { ev } = makeEnv();
    assert.strictEqual(ev(`fmtC('$',-1e-17)`), '$0.00');
    assert.strictEqual(ev(`sumA([{amount:0.1},{amount:0.2}])`), 0.3);
    assert.strictEqual(ev(`fmtC('$',-12.5)`), '−$12.50');
  });

  await t('number parser handles common formats', async () => {
    const { ev } = makeEnv();
    for (const [i, o] of [['12.50', 12.5], ['1,234.56', 1234.56], ['1.234,56', 1234.56], ['12,5', 12.5], ['abc', 0], ['', 0], ['1,234', 1234]]) assert.strictEqual(ev(`num(${J(i)})`), o, i);
  });

  await t('currency symbol is HTML-escaped everywhere it is printed', async () => {
    const { ev } = makeEnv();
    assert(ev(`fmtC('<b>',5)`).includes('&lt;b&gt;'));
  });

  await t('invalid amounts and dates are rejected by the data layer', async () => {
    const { ev } = makeEnv();
    for (const bad of [`{date:'2026-10-01',amount:0,cat:'Salary'}`, `{date:'2026-10-01',amount:-5,cat:'Salary'}`, `{date:'nope',amount:5,cat:'Salary'}`, `{date:'2026-10-01',amount:1e13,cat:'Salary'}`]) {
      const before = ev(`DB.inc.length`);
      await ev(`api('inc_save',${bad})`);
      assert.strictEqual(ev(`readDB().inc.length`), before, bad);
    }
  });

  await t('rejects impossible calendar dates including invalid leap days', async () => {
    const { ev } = makeEnv();
    for (const date of ['2026-02-31', '2025-02-29', '2026-13-01', '2026-04-31']) {
      assert.strictEqual(ev(`validDate(${J(date)})`), false, date);
      await ev(`api('inc_save',{date:${J(date)},amount:10,cat:'Salary'})`);
      assert.strictEqual(ev('DB.inc.length'), 0, date);
    }
    assert.strictEqual(ev(`validDate('2024-02-29')`), true);
  });

  await t('rejects transfers without a valid destination account', async () => {
    const { ev } = makeEnv();
    await ev(`api('tx_save',{date:'2026-10-10',type:'transfer',amount:25,cat:'Transfer'})`);
    assert.strictEqual(ev('DB.tx.length'), 0);
    await ev(`api('tx_save',{date:'2026-10-10',type:'transfer',amount:25,cat:'Transfer',to:1})`);
    assert.strictEqual(ev('DB.tx.length'), 0);
    await ev(`api('acc_save',{name:'Second',icon:'💵',cur:'$',pocket:0,pocketMonth:'2026-10'})`);
    const destination=ev('S.account');
    ev('S.account=1;S.plan=1');
    await ev(`api('tx_save',{date:'2026-10-10',type:'transfer',amount:25,cat:'Transfer',to:${destination}})`);
    assert.strictEqual(ev('DB.tx.length'), 1);
    assert.strictEqual(ev('DB.tx[0].to'), destination);
  });

  await t('blocks transfers between different currencies until conversion is supported', async () => {
    const { ev } = makeEnv();
    await ev(`api('acc_save',{name:'Ringgit',icon:'💵',cur:'RM',pocket:0,pocketMonth:'2026-10'})`);
    const ringgit=ev('S.account');
    ev('S.account=1;S.plan=1'); await ev(`api('nav')`);
    await ev(`api('tx_save',{date:'2026-10-10',type:'transfer',amount:25,cat:'Transfer',to:${ringgit}})`);
    assert.strictEqual(ev('DB.tx.length'), 0);
  });

  await t('transfer destinations in backups must be valid', async () => {
    const { ev } = makeEnv();
    const bad = {format:'money-manager-backup',version:2,accounts:[{id:1,name:'A',icon:'🏦',cur:'$',pocket:0,pocketMonth:'2026-10'}],plans:[{id:1,account:1,name:'General',icon:'🏠'}],tx:[{id:1,plan:1,date:'2026-10-10',type:'transfer',amount:20,to:null,cat:'Transfer'}],inc:[],budgets:[],goals:[]};
    assert.throws(() => ev(`clean(${J(bad)})`), /missing or invalid destination account/);
  });

  await t('corrupt saved data is quarantined instead of silently overwritten', async () => {
    const { ev, store } = makeEnv();
    const raw = '{not valid json';
    store.set('mm_db', raw);
    ev('DB=readDB()');
    const recoveryKeys = [...store.keys()].filter(k => k.startsWith('mm_db_recovery_'));
    assert.strictEqual(recoveryKeys.length, 1);
    assert.strictEqual(store.get(recoveryKeys[0]), raw);
    assert.strictEqual(store.has('mm_db'), false);
    assert(ev('dbRecoveryWarning').includes('recovery copy'));
    assert(ev('dbRecoveryKey').startsWith('mm_db_recovery_'));
    assert(ev('vSet()').includes('Export recovery copy'));
  });

  await t('monthly expense totals exclude transfers', async () => {
    const { ev } = makeEnv();
    await ev(`api('acc_save',{name:'Second',icon:'💵',cur:'$',pocket:0,pocketMonth:'2026-10'})`);
    const second=ev('S.account');
    ev('S.account=1;S.plan=1'); await ev(`api('nav')`);
    await ev(`api('inc_save',{date:'2026-10-01',month:'2026-10',amount:1000,cat:'Salary'})`);
    await ev(`api('tx_save',{date:'2026-10-02',type:'expense',amount:100,cat:'Food'})`);
    await ev(`api('tx_save',{date:'2026-10-03',type:'transfer',amount:200,cat:'Transfer',to:${second}})`);
    ev(`M='2026-10';DB=readDB();S=state(1,1)`);
    assert.strictEqual(ev(`allM('2026-10')`), 100);
    assert.strictEqual(ev(`flow(DB,1,'2026-10').bal`), 700);
    ev(`tab='home';render()`);
    const html=ev(`vDash()`);
    assert(html.includes('Spent'));
    assert(!html.includes('Transfer</span>'), 'transfer must not be listed as a spending category');
  });

  await t('savings goal stays in sync when its deposit is edited or deleted', async () => {
    const { ev } = makeEnv();
    await ev(`api('inc_save',{date:'2026-10-01',month:'2026-10',amount:1000,cat:'Salary'})`);
    await ev(`api('goal_save',{name:'Laptop',icon:'💻',target:900})`);
    const gid = ev(`DB.goals[0].id`);
    await ev(`api('goal_add',{id:${gid},amount:200,date:'2026-10-02'})`);
    assert.strictEqual(ev(`DB.goals[0].saved`), 200);
    const txid = ev(`DB.tx[0].id`);
    await ev(`api('tx_save',{id:${txid},date:'2026-10-02',type:'transfer',amount:300,cat:'Food'})`);
    assert.strictEqual(ev(`DB.goals[0].saved`), 300);
    assert.strictEqual(ev(`DB.tx[0].cat`), 'Savings');
    assert.strictEqual(ev(`DB.tx[0].type`), 'expense');
    await ev(`api('tx_del',{id:${txid}})`);
    assert.strictEqual(ev(`DB.goals[0].saved`), 0);
  });

  await t('availability check ignores the transaction being edited', async () => {
    const { ev } = makeEnv();
    await ev(`api('inc_save',{date:'2026-10-01',month:'2026-10',amount:100,cat:'Salary'})`);
    await ev(`api('tx_save',{date:'2026-10-03',type:'expense',amount:100,cat:'Food'})`);
    const id = ev(`DB.tx[0].id`);
    assert.strictEqual(ev(`availFor(1,'2026-10')`), 0);
    assert.strictEqual(ev(`availFor(1,'2026-10',${id})`), 100);
  });

  await t('malicious backup is sanitised and cannot inject HTML', async () => {
    const { ev, els } = makeEnv();
    const evil = { format: 'money-manager-backup', version: 2, accounts: [{ id: 1, name: '<img src=x onerror=alert(1)>', icon: '<script>x</script>', cur: '<img src=x onerror=1>', pocket: '5', pocketMonth: 'bad' }],
      plans: [{ id: 1, account: 1, name: '<b>p</b>', icon: '"><svg onload=1>' }, { id: 2, account: 99, name: 'orphan', icon: '🏠' }],
      tx: [{ id: 1, plan: 1, date: '2026-10-01', type: 'expense', amount: 5, cat: '<img onerror=1>', note: '<i>n</i>' }, { id: 2, plan: 1, date: '"><x>', type: 'expense', amount: 5, cat: 'Food' }, { id: 3, plan: 77, date: '2026-10-01', amount: 5, cat: 'Food' }],
      inc: [{ id: 1, account: 1, date: '2026-10-01', amount: 9, cat: '<u>', note: '' }], budgets: [{ plan: 1, cat: '<img>', lim: 10 }], goals: [{ id: 1, plan: 1, name: '<g>', icon: '<g>', target: 5, saved: 1 }] };
    const N = ev(`clean(${J(evil)})`);
    assert.strictEqual(N.plans.length, 1); assert.strictEqual(N.tx.length, 1); assert.strictEqual(N.budgets.length, 0);
    assert.strictEqual(N.tx[0].cat, 'Other'); assert.strictEqual(N.inc[0].cat, 'Other');
    assert(N.accounts[0].cur.length <= 4); assert(!['🏦', '💵', '👛', '💳', '🏠', '💼', '🎓', '✈️', '💰', '🪙', '📱'].every(x => x !== N.accounts[0].icon) );
    assert(/^\d{4}-\d{2}$/.test(N.accounts[0].pocketMonth));
    ev(`DB=${J(N)};writeDB();load()`);
    for (const tab of ['home', 'act', 'bud', 'goal', 'ins', 'acc', 'set']) { ev(`tab='${tab}';render()`); const h = els['#main'].innerHTML; assert(!/<img\s|<script|<svg onload/i.test(h), 'injection survived in ' + tab); }
  });

  await t('backup round-trips and keeps the month data', async () => {
    const { ev } = makeEnv();
    await ev(`api('inc_save',{date:'2026-10-05',month:'2026-12',amount:321,cat:'Gift',note:'xmas'})`);
    await ev(`api('tx_save',{date:'2026-12-10',type:'expense',amount:21,cat:'Fun'})`);
    await ev(`api('carry_set',{v:true})`);
    const raw = ev(`backupData()`), o = JSON.parse(raw);
    const N = ev(`clean(${raw})`);
    assert.strictEqual(N.inc[0].month, '2026-12'); assert.strictEqual(N.carry, true); assert.strictEqual(N.tx.length, 1);
    assert.strictEqual(o.accounts[0].pocketMonth, ev(`DB.accounts[0].pocketMonth`));
  });

  await t('old v1 backup format still restores', async () => {
    const { ev } = makeEnv();
    const v1 = { format: 'money-manager-backup', version: 1, plans: [{ id: 1, name: 'Personal', icon: '🏠', cur: '€' }], accounts: [{ init: 50 }], tx: [{ id: 1, plan: 1, type: 'income', date: '2026-01-02', amount: 100, cat: 'Salary' }, { id: 2, plan: 1, type: 'expense', date: '2026-01-03', amount: 20, cat: 'Food' }], budgets: [], goals: [] };
    const N = ev(`clean(migrate(${J(v1)}))`);
    assert.strictEqual(N.inc.length, 1); assert.strictEqual(N.tx.length, 1); assert.strictEqual(N.inc[0].month, '2026-01');
  });

  await t('CSV export neutralises spreadsheet formulas and includes the month', async () => {
    const { ev } = makeEnv();
    await ev(`api('inc_save',{date:'2026-10-05',month:'2026-11',amount:10,cat:'Gift',note:'=HYPERLINK("x")'})`);
    ev(`var __csv='';saveFile=(n,d)=>{__csv=d}`); ev(`exportCSV()`);
    const csv = ev(`__csv`);
    assert(csv.startsWith('\ufeff')); assert(csv.includes(`"'=HYPERLINK`)); assert(csv.includes('"2026-11"'));
  });

  await t('month navigation recomputes balances', async () => {
    const { ev } = makeEnv();
    await ev(`api('inc_save',{date:'2026-10-05',month:'2026-10',amount:100,cat:'Salary'})`);
    ev(`M='2026-10';DB=readDB();S=state(S.account,S.plan)`); assert.strictEqual(ev(`curAcc().bal`), 100);
    ev(`shift(1)`); assert.strictEqual(ev(`M`), '2026-11'); assert.strictEqual(ev(`curAcc().bal`), 0);
    ev(`shift(-1)`); assert.strictEqual(ev(`curAcc().bal`), 100);
    ev(`M='2026-12';shift(1)`); assert.strictEqual(ev(`M`), '2027-01');
  });

  await t('deleting an account/plan keeps data consistent', async () => {
    const { ev } = makeEnv();
    await ev(`api('acc_save',{name:'B',icon:'💵',cur:'$',pocket:10,pocketMonth:'2026-10'})`);
    const id = ev(`S.account`);
    await ev(`api('inc_save',{date:'2026-10-01',month:'2026-10',amount:5,cat:'Other'})`);
    await ev(`api('acc_del',{id:${id}})`);
    assert.strictEqual(ev(`DB.accounts.length`), 1); assert.strictEqual(ev(`DB.inc.length`), 0);
    ev(`tab='home';render()`);
  });

  await t('every form opens, and the income form has the month picker', async () => {
    const { ev, els } = makeEnv();
    await ev(`api('inc_save',{date:'2026-10-05',month:'2026-10',amount:100,cat:'Salary'})`);
    await ev(`api('goal_save',{name:'G',icon:'🎯',target:50})`);
    ev(`M='2026-10';DB=readDB();S=state(S.account,S.plan)`);
    ev(`incForm()`); const h = els['#sheet'].innerHTML; assert(h.includes('id="imm"') && h.includes('id="imy"') && h.includes('Counts for month'), 'month picker missing');
    assert(/<option value="10" selected>/.test(h), 'defaults to the viewed month');
    ev(`incForm(${ev('S.inc[0].id')})`);
    for (const c of [`txForm()`, `accForm()`, `accForm(1)`, `planForm()`, `goalForm()`, `budForm('Food')`, `goalAdd(${ev('S.goals[0].id')})`, `setType('transfer')`]) { ev(c); assert(els['#sheet'].innerHTML.length > 20, c); }
    ev(`accForm(1)`); assert(!els['#sheet'].innerHTML.toLowerCase().includes('pocket money'), 'pocket money UI should be removed');
  });

  await t('PIN: set, verify and wrong PIN', async () => {
    const { ev } = makeEnv();
    ev(`DB=readDB();const salt=rnd();DB.pin={salt,hash:pinHash('1234',salt)};writeDB()`);
    assert.strictEqual(ev(`pinOK('1234')`), true); assert.strictEqual(ev(`pinOK('4321')`), false);
  });

  console.log(`\n${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})();
