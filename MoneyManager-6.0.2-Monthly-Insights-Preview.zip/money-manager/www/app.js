window.addEventListener('error',e=>{const b=document.createElement('div');b.style.cssText='position:fixed;left:8px;right:8px;top:8px;z-index:99;background:#fff3cd;color:#5c3d00;border:1px solid #d98a00;border-radius:12px;padding:10px;font:13px system-ui,sans-serif';b.textContent='Something went wrong: '+(e.message||'unknown error')+' (line '+e.lineno+'). Please report it on the GitHub Issues page.';document.body.appendChild(b)});
const CE={Food:'🍔',Transport:'🚗',Bills:'💡',Shopping:'🛍️',Health:'💊',Fun:'🎬',Education:'📚',Savings:'🎯',Other:'📦'};
const CI={Salary:'💼',Business:'🏪',Gift:'🎁',Other:'💰'};
const EXP=Object.keys(CE),INC=Object.keys(CI),COL=['#0e7c66','#cf3f55','#d98a00','#3b6fd4','#8a4fd0','#e0679a','#2fa8b8','#7a8b2e','#8c8c8c'];
const PI=['🏠','💼','🏪','🎓','✈️','👪','🎉','📁'],WI=['💵','🏦','💳','📱','💰','🪙','🏠','✈️'],GI=['🎯','🏖️','🚗','🏠','💻','📱','🎓','💍'];
const PAGE_VER='6.0.2';
let S={account:0,plan:0,plans:[],accounts:[],tx:[],atx:[],inc:[],aplans:[],abud:[],agoals:[],budgets:[],goals:[],settings:{}},tab='home',flt='all',q='',F={},W={},G={};
const $=s=>document.querySelector(s);
const today=()=>new Date(Date.now()-new Date().getTimezoneOffset()*6e4).toISOString().slice(0,10);
let M=today().slice(0,7);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const cur=()=>S.settings.cur||'$';
const r2=x=>Math.round((+x||0)*100)/100;
const monthOf=d=>String(d).slice(0,7),MK=/^\d{4}-(0[1-9]|1[0-2])$/;
const fmtC=(c,n)=>{n=r2(n);return (n<0?'−':'')+esc(c)+Math.abs(n).toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2})};
const fmt=n=>fmtC(cur(),n);
const num=v=>{let t=String(v??'').replace(/[^\d.,-]/g,'');
 if(t.includes(',')&&t.includes('.')){t=t.lastIndexOf(',')>t.lastIndexOf('.')?t.replace(/\./g,'').replace(',','.'):t.replace(/,/g,'')}
 else if(/,\d{1,2}$/.test(t))t=t.replace(/,(\d{1,2})$/,'.$1');else t=t.replace(/,/g,'');
 const x=parseFloat(t);return isNaN(x)?0:x};
const val=(id,f)=>{const e=document.getElementById(id);return e?e.value:f};
const curAcc=()=>S.accounts.find(a=>a.id==S.account)||{id:0,name:'',icon:'🏦',cur:'$',bal:0,pocket:0};
const sumA=l=>r2(l.reduce((s,t)=>s+t.amount,0));
const exM=m=>sumA(S.tx.filter(t=>t.type=='expense'&&t.date.startsWith(m)));
const inM=m=>sumA(S.inc.filter(t=>t.month==m));
const allM=m=>sumA(S.atx.filter(t=>t.type=='expense'&&t.date.startsWith(m))); // transfers are not spending
const tot=(ty,m)=>ty=='income'?inM(m):allM(m);
const spent=(c,m=M)=>sumA(S.tx.filter(t=>t.type=='expense'&&t.cat==c&&t.date.startsWith(m)));
const lim=c=>(S.budgets.find(b=>b.cat==c)||{}).lim||0;
const toast=m=>{const t=$('#toast');t.textContent=m;t.classList.add('show');clearTimeout(toast.t);toast.t=setTimeout(()=>t.classList.remove('show'),2400)};
/* ---------- local database: accounts (money) -> plans (activity, budgets, goals) ---------- */
let DB=null,mem=null,storeOK=true;
const emptyDB=()=>({v:2,n:{acc:2,plan:2,tx:1,inc:1,goal:1},accounts:[{id:1,name:'Main Account',icon:'🏦',cur:'$',pocket:0,pocketMonth:today().slice(0,7)}],plans:[{id:1,account:1,name:'General',icon:'🏠'}],tx:[],inc:[],budgets:[],goals:[],pin:null,carry:false,backup:0,last:{acc:1,plan:1}});
function migrate(o){const pls=o.plans&&o.plans.length?o.plans:[{id:1,name:'Personal',icon:'🏠',cur:'$'}];
 const D={v:2,accounts:[{id:1,name:'Main Account',icon:'🏦',cur:pls[0].cur||'$',pocket:(o.accounts||[]).reduce((a,w)=>a+(+w.init||0),0)}],plans:pls.map(p=>({id:p.id,account:1,name:p.name,icon:p.icon})),tx:[],inc:[],budgets:o.budgets||[],goals:o.goals||[],pin:o.pin||null,last:{acc:1,plan:pls[0].id}};
 for(const t of o.tx||[]){if(t.type=='income')D.inc.push({account:1,date:t.date,amount:t.amount,cat:t.cat,note:t.note||''});else if(t.type=='expense')D.tx.push({plan:t.plan,date:t.date,type:'expense',amount:t.amount,cat:t.cat,to:null,note:t.note||''})}
 D.tx.forEach((t,i)=>t.id=i+1);D.inc.forEach((t,i)=>t.id=i+1);const mx=a=>Math.max(0,...a.map(x=>x.id))+1;D.n={acc:2,plan:mx(D.plans),tx:mx(D.tx),inc:mx(D.inc),goal:mx(D.goals)};return D}

/* ---------- month model: every pocket/income/expense belongs to ONE month ---------- */
function norm(D){D.carry=!!D.carry;D.backup=+D.backup||0;
 D.accounts.forEach(a=>{if(!MK.test(a.pocketMonth||'')){const ps=D.plans.filter(p=>p.account==a.id).map(p=>p.id),
  ds=[...D.tx.filter(t=>ps.includes(t.plan)).map(t=>t.date),...D.inc.filter(i=>i.account==a.id).map(i=>i.date)].filter(Boolean).sort();
  a.pocketMonth=ds.length?monthOf(ds[0]):today().slice(0,7)}});
 D.inc.forEach(i=>{if(!MK.test(i.month||''))i.month=monthOf(i.date)});return D}
/* Money picture of one account in month m. carry=false: each month starts fresh. carry=true: leftovers roll forward. */
function flow(D,a,m){const Z={pocket:0,inc:0,tin:0,spent:0,carried:0,inn:0,bal:0},A=D.accounts.find(z=>z.id==a);if(!A)return Z;
 const ps=D.plans.filter(p=>p.account==a).map(p=>p.id),tr=D.tx.filter(t=>t.type=='transfer'&&t.to==a);
 const net=f=>r2((f(A.pocketMonth)?A.pocket:0)+sumA(D.inc.filter(i=>i.account==a&&f(i.month)))+sumA(tr.filter(t=>f(monthOf(t.date))))-sumA(D.tx.filter(t=>ps.includes(t.plan)&&f(monthOf(t.date)))));
 Z.pocket=A.pocketMonth==m?A.pocket:0;Z.inc=sumA(D.inc.filter(i=>i.account==a&&i.month==m));Z.tin=sumA(tr.filter(t=>monthOf(t.date)==m));
 Z.spent=sumA(D.tx.filter(t=>ps.includes(t.plan)&&monthOf(t.date)==m));
 Z.carried=D.carry?net(k=>k<m):0;Z.inn=r2(Z.carried+Z.pocket+Z.inc+Z.tin);Z.bal=r2(Z.inn-Z.spent);return Z}
/* money still available for a month (optionally ignoring one existing transaction that is being edited) */
function availFor(acc,month,skipId){DB=readDB();let b=flow(DB,acc,month).bal;
 if(skipId){const t=DB.tx.find(t=>t.id==skipId);if(t&&monthOf(t.date)==month&&DB.plans.some(p=>p.id==t.plan&&p.account==acc))b=r2(b+t.amount)}return b}
const chkAmt=a=>{a=r2(a);if(!(a>0&&a<1e12))throw new Error('Enter a valid amount');return a};
const validDate=d=>{if(typeof d!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(d))return false;const [y,m,day]=d.split('-').map(Number);const dt=new Date(Date.UTC(y,m-1,day));return dt.getUTCFullYear()===y&&dt.getUTCMonth()===m-1&&dt.getUTCDate()===day};
const chkDate=d=>{if(!validDate(d))throw new Error('Pick a valid date');return d};
/* rebuild a clean database from a backup file: unknown fields dropped, text trimmed, links checked */
function clean(D){const L=Array.isArray,s=(v,n)=>String(v??'').slice(0,n).trim(),pick=(v,l)=>l.includes(v)?v:l[0],cat=(v,l)=>l.includes(v)?v:'Other',isId=v=>Number.isInteger(v)&&v>0,
 big=v=>{v=r2(v);return Math.abs(v)<1e12?v:0},arr=a=>L(a)?a.filter(x=>x&&typeof x=='object'):[],
 dOK=validDate,
 uniq=a=>{const seen=new Set();return a.filter(x=>!seen.has(x.id)&&seen.add(x.id))},mx=a=>a.reduce((m,x)=>Math.max(m,x.id),0)+1;
 const accounts=uniq(arr(D.accounts).filter(a=>isId(a.id))).map(a=>({id:a.id,name:s(a.name,40)||'Account',icon:pick(a.icon,[...AI,...WI]),cur:s(a.cur,4)||'$',pocket:big(a.pocket),pocketMonth:a.pocketMonth}));
 if(!accounts.length)throw new Error('no accounts');
 const aid=new Set(accounts.map(a=>a.id));
 const plans=uniq(arr(D.plans).filter(p=>isId(p.id)&&aid.has(p.account))).map(p=>({id:p.id,account:p.account,name:s(p.name,40)||'Plan',icon:pick(p.icon,PI)}));
 let pn=mx(plans);accounts.forEach(a=>{if(!plans.some(p=>p.account==a.id))plans.push({id:pn++,account:a.id,name:'General',icon:'📁'})});
 const pid=new Set(plans.map(p=>p.id)),acOf={};plans.forEach(p=>acOf[p.id]=p.account);
 const rawTx=arr(D.tx);
 if(rawTx.some(t=>t.type=='transfer'&&pid.has(t.plan)&&(!isId(t.to)||!aid.has(t.to)||t.to==acOf[t.plan])))throw new Error('Backup contains a transfer with a missing or invalid destination account');
 const tx=uniq(rawTx.filter(t=>isId(t.id)&&pid.has(t.plan)&&dOK(t.date)&&r2(t.amount)>0)).map(t=>{const tr=t.type=='transfer';
  return {id:t.id,plan:t.plan,date:t.date,type:tr?'transfer':'expense',amount:big(t.amount),cat:tr?'Transfer':cat(t.cat,EXP),to:tr&&aid.has(t.to)&&t.to!=acOf[t.plan]?t.to:null,note:s(t.note,200),...(isId(t.goal)?{goal:t.goal}:{})}});
 const inc=uniq(arr(D.inc).filter(i=>isId(i.id)&&aid.has(i.account)&&dOK(i.date)&&r2(i.amount)>0)).map(i=>({id:i.id,account:i.account,date:i.date,month:MK.test(i.month||'')?i.month:i.date.slice(0,7),amount:big(i.amount),cat:cat(i.cat,INC),note:s(i.note,200)}));
 const seen=new Set(),budgets=arr(D.budgets).filter(b=>pid.has(b.plan)&&EXP.includes(b.cat)&&r2(b.lim)>0&&!seen.has(b.plan+'|'+b.cat)&&seen.add(b.plan+'|'+b.cat)).map(b=>({plan:b.plan,cat:b.cat,lim:big(b.lim)}));
 const goals=uniq(arr(D.goals).filter(g=>isId(g.id)&&pid.has(g.plan)&&r2(g.target)>0)).map(g=>({id:g.id,plan:g.plan,name:s(g.name,40)||'Goal',icon:pick(g.icon,GI),target:big(g.target),saved:Math.max(0,big(g.saved))}));
 return norm({v:2,n:{acc:mx(accounts),plan:mx(plans),tx:mx(tx),inc:mx(inc),goal:mx(goals)},accounts,plans,tx,inc,budgets,goals,pin:null,carry:!!D.carry,backup:0,last:{acc:accounts[0].id,plan:plans.find(p=>p.account==accounts[0].id).id}})}
let dbRecoveryWarning='',dbRecoveryKey='',dbWriteBlocked=false;
try{localStorage.setItem('mm_t','1');localStorage.removeItem('mm_t')}catch(e){storeOK=false}
function readDB(){if(!dbRecoveryKey){try{for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(k&&k.startsWith('mm_db_recovery_')){dbRecoveryKey=k;break}}}catch(_){}}let t=null;try{t=localStorage.getItem('mm_db')}catch(e){storeOK=false;return mem||norm(emptyDB())}
 if(t){try{const o=JSON.parse(t);if(!o||typeof o!='object'||Array.isArray(o))throw new Error('Invalid database');return norm(o.v==2?o:migrate(o))}
 catch(e){storeOK=false;let key='mm_db_recovery_'+Date.now(),saved=false;try{localStorage.setItem(key,t);saved=localStorage.getItem(key)===t}catch(_){}
  if(saved){dbRecoveryKey=key;try{localStorage.removeItem('mm_db');dbWriteBlocked=false;storeOK=true;dbRecoveryWarning='Saved unreadable data to '+key+'. The app started with fresh data; export the recovery copy from Settings if you need it.'}catch(_){dbWriteBlocked=true;dbRecoveryWarning='Unreadable data was copied to '+key+', but the original storage could not be cleared. Saving is disabled to protect it.'}}
  else{dbWriteBlocked=true;dbRecoveryWarning='Saved data could not be read and a recovery copy could not be created. Saving is disabled to protect the original data.'}
  return mem||norm(emptyDB())}}return mem||norm(emptyDB())}
function writeDB(){if(dbWriteBlocked){storeOK=false;return false}try{localStorage.setItem('mm_db',JSON.stringify(DB));mem=DB;storeOK=true;return true}catch(e){storeOK=false;return false}}
const nid=k=>DB.n[k]++;
const resAcc=a=>DB.accounts.some(z=>z.id==a)?+a:DB.accounts[0].id;
function doAct(a,d,x){x.acc=resAcc(x.acc);const pls=DB.plans.filter(p=>p.account==x.acc);x.plan=pls.some(p=>p.id==x.plan)?+x.plan:pls[0].id;const pid=x.plan;
 switch(a){
 case 'tx_save':{const existing=d.id?DB.tx.find(t=>t.id==d.id&&t.plan==pid):null,tr=existing&&existing.goal?false:d.type=='transfer',to=tr?(+d.to||0):null;if(tr&&(!to||to==x.acc||!DB.accounts.some(z=>z.id==to)))throw new Error('Choose a valid destination account for this transfer');if(tr&&DB.accounts.find(z=>z.id==to).cur!=DB.accounts.find(z=>z.id==x.acc).cur)throw new Error('Transfers between different currencies are not supported yet. Choose an account using the same currency.');
  const v={date:chkDate(d.date),type:tr?'transfer':'expense',amount:chkAmt(d.amount),cat:tr?'Transfer':(EXP.includes(d.cat)?d.cat:'Other'),to,note:String(d.note||'').slice(0,200)};
  if(d.id){const t=existing;if(t){if(t.goal){const g=DB.goals.find(g=>g.id==t.goal);if(g)g.saved=Math.max(0,r2(g.saved+v.amount-t.amount));Object.assign(v,{type:'expense',cat:'Savings',to:null})}Object.assign(t,v)}}else DB.tx.push({id:nid('tx'),plan:pid,...v});break}
 case 'tx_del':{const t=DB.tx.find(t=>t.id==d.id&&t.plan==pid);if(t&&t.goal){const g=DB.goals.find(g=>g.id==t.goal);if(g)g.saved=Math.max(0,r2(g.saved-t.amount))}DB.tx=DB.tx.filter(t=>!(t.id==d.id&&t.plan==pid));break}
 case 'inc_save':{const date=chkDate(d.date),v={date,month:MK.test(d.month||'')?d.month:monthOf(date),amount:chkAmt(d.amount),cat:INC.includes(d.cat)?d.cat:'Other',note:String(d.note||'').slice(0,200)};if(d.id){const i=DB.inc.find(i=>i.id==d.id&&i.account==x.acc);if(i)Object.assign(i,v)}else DB.inc.push({id:nid('inc'),account:x.acc,...v});break}
 case 'inc_del':DB.inc=DB.inc.filter(i=>!(i.id==d.id&&i.account==x.acc));break;
 case 'acc_save':{const pk=r2(d.pocket);if(Math.abs(pk)>=1e12)throw new Error('Amount too large');const v={name:(d.name||'').trim().slice(0,40)||'Account',icon:d.icon,cur:String(d.cur||'$').trim().slice(0,4)||'$',pocket:pk,pocketMonth:MK.test(d.pocketMonth||'')?d.pocketMonth:today().slice(0,7)};
  if(d.id){const z=DB.accounts.find(z=>z.id==d.id);if(z)Object.assign(z,v)}else{const id=nid('acc'),p=nid('plan');DB.accounts.push({id,...v});DB.plans.push({id:p,account:id,name:'General',icon:'📁'});x.acc=id;x.plan=p}break}
 case 'acc_del':if(DB.accounts.length>1){const ps=DB.plans.filter(p=>p.account==d.id).map(p=>p.id);DB.tx=DB.tx.filter(t=>!ps.includes(t.plan));DB.tx.forEach(t=>{if(t.to==d.id)t.to=0});
  DB.budgets=DB.budgets.filter(b=>!ps.includes(b.plan));DB.goals=DB.goals.filter(g=>!ps.includes(g.plan));DB.plans=DB.plans.filter(p=>p.account!=d.id);DB.inc=DB.inc.filter(i=>i.account!=d.id);DB.accounts=DB.accounts.filter(z=>z.id!=d.id);x.acc=0;x.plan=0}break;
 case 'budget_set':DB.budgets=DB.budgets.filter(b=>!(b.plan==pid&&b.cat==d.cat));if(r2(d.lim)>0&&EXP.includes(d.cat))DB.budgets.push({plan:pid,cat:d.cat,lim:Math.min(r2(d.lim),1e11)});break;
 case 'goal_save':{const v={name:String(d.name||'').slice(0,40),icon:d.icon,target:chkAmt(d.target)};if(d.id){const g=DB.goals.find(g=>g.id==d.id&&g.plan==pid);if(g)Object.assign(g,v)}else DB.goals.push({id:nid('goal'),plan:pid,saved:0,...v});break}
 case 'goal_del':DB.goals=DB.goals.filter(g=>!(g.id==d.id&&g.plan==pid));break;
 case 'goal_add':{const g=DB.goals.find(g=>g.id==d.id&&g.plan==pid);if(!g)throw new Error('Goal not found in this plan');const amt=chkAmt(d.amount);g.saved=r2(g.saved+amt);
  DB.tx.push({id:nid('tx'),plan:pid,date:chkDate(d.date),type:'expense',amount:amt,cat:'Savings',to:null,note:'Goal: '+g.name,goal:g.id});break}
 case 'plan_save':{const name=(d.name||'').trim()||'My plan';if(d.id){const p=DB.plans.find(p=>p.id==d.id&&p.account==x.acc);if(p)Object.assign(p,{name,icon:d.icon})}else{const id=nid('plan');DB.plans.push({id,account:x.acc,name,icon:d.icon});x.plan=id}break}
 case 'plan_del':if(pls.length>1&&pls.some(p=>p.id==d.id)){DB.tx=DB.tx.filter(t=>t.plan!=d.id);DB.budgets=DB.budgets.filter(b=>b.plan!=d.id);DB.goals=DB.goals.filter(g=>g.plan!=d.id);DB.plans=DB.plans.filter(p=>p.id!=d.id);if(d.id==x.plan)x.plan=0}break;
 case 'carry_set':DB.carry=!!d.v;break;
 case 'backup_mark':DB.backup=Date.now();break;
 case 'cur_set':{const c=String(d.v||'').trim().slice(0,4)||'$';DB.accounts.forEach(z=>{if(d.all||z.id==x.acc)z.cur=c});break}
 }
 DB.last={acc:x.acc,plan:x.plan};return x}
const byDate=(x,y)=>x.date<y.date?1:x.date>y.date?-1:String(y.id).localeCompare(String(x.id),undefined,{numeric:true});
function state(a,p){a=resAcc(a);const A=DB.accounts.find(z=>z.id==a),pls=DB.plans.filter(q=>q.account==a);p=pls.some(q=>q.id==p)?+p:pls[0].id;const ps=pls.map(q=>q.id);
 const sum=sumA;
 const nm=id=>(DB.accounts.find(z=>z.id==id)||{}).name||'';
 const tin=DB.tx.filter(t=>t.type=='transfer'&&t.to==a).map(t=>({id:'t'+t.id,date:t.date,amount:t.amount,cat:'Transfer in',note:'From '+nm((DB.plans.find(q=>q.id==t.plan)||{}).account),kind:'tin',month:monthOf(t.date)}));
 return {account:a,plan:p,accounts:DB.accounts.map(z=>{const f=flow(DB,z.id,M);return {...z,f,bal:f.bal}}),plans:pls.map(q=>({...q})),tx:DB.tx.filter(t=>t.plan==p).sort(byDate),atx:DB.tx.filter(t=>ps.includes(t.plan)),
 inc:[...DB.inc.filter(i=>i.account==a).map(i=>({...i,kind:'inc'})),...tin].sort(byDate),budgets:DB.budgets.filter(b=>b.plan==p).map(({cat,lim})=>({cat,lim})),
 goals:DB.goals.filter(g=>g.plan==p).map(({id,name,icon,target,saved})=>({id,name,icon,target,saved})),aplans:DB.plans.map(q=>({...q,spent:sum(DB.tx.filter(t=>t.plan==q.id&&monthOf(t.date)==M))})),abud:DB.budgets.filter(b=>ps.includes(b.plan)),agoals:DB.goals.filter(g=>ps.includes(g.plan)),settings:{cur:A.cur||'$',has_pin:DB.pin?1:0,carry:!!DB.carry,backup:DB.backup||0,hasData:DB.tx.length+DB.inc.length>0}}}
async function api(a,d={}){try{DB=readDB();const x=doAct(a,{...d},{acc:S.account,plan:S.plan});if(!writeDB())throw new Error('Data could not be saved. Your existing data has been protected; make a backup or free device storage.');S=state(x.acc,x.plan);render();return true}catch(e){toast('Error: '+e.message)}}
function load(){DB=readDB();const l=DB.last||{};S=state(S.account||l.acc,S.plan||l.plan);render();document.body.classList.add('ready')}
const sheet=h=>{$('#sheet').innerHTML=`<div class="ov" onclick="closeS()"></div><div class="sh">${h}</div>`;$('#sheet').style.display='block'};
const closeS=()=>{$('#sheet').style.display='none';$('#sheet').innerHTML=''};
const shift=d=>{let[y,m]=M.split('-').map(Number);m+=d;if(m>12){m=1;y++}if(m<1){m=12;y--}M=y+'-'+String(m).padStart(2,'0');DB=readDB();S=state(S.account,S.plan);render()};
const goNow=()=>{M=today().slice(0,7);DB=readDB();S=state(S.account,S.plan);render()};
const mname=m=>new Date(m+'-01T00:00').toLocaleString(undefined,{month:'long',year:'numeric'});
const mshort=m=>new Date(m+'-01T00:00').toLocaleString(undefined,{month:'short',year:'numeric'});
const defDate=()=>M==today().slice(0,7)?today():M+'-01';
const monBar=()=>`<div class="mon"><button onclick="shift(-1)">‹</button><b onclick="goNow()" style="cursor:pointer" title="Jump to this month">${mname(M)}</b><button onclick="shift(1)">›</button></div>`;
const go=t=>{tab=t;render();scrollTo(0,0)};

/* ---------- charts ---------- */
function donut(items){const T=items.reduce((s,i)=>s+i[1],0);if(!T)return '<p class="mut">No spending this month yet.</p>';let o=25;
 const segs=items.map((i,k)=>{const p=i[1]/T*100,r=`<circle cx="21" cy="21" r="15.9155" fill="none" stroke="${COL[k%COL.length]}" stroke-width="6" stroke-dasharray="${p} ${100-p}" stroke-dashoffset="${o}"/>`;o-=p;return r}).join('');
 return `<div class="two" style="align-items:center;background:none"><svg viewBox="0 0 42 42" class="donut"><circle cx="21" cy="21" r="15.9155" fill="none" stroke="var(--bd)" stroke-width="6"/>${segs}</svg>
 <div class="legend">${items.slice(0,6).map((i,k)=>`<div><span><i style="background:${COL[k%COL.length]}"></i>${i[0]}</span><b>${Math.round(i[1]/T*100)}%</b></div>`).join('')}</div></div>`}
function bars(){const ms=[];let[y,m]=M.split('-').map(Number);for(let i=5;i>=0;i--){let mm=m-i,yy=y;while(mm<1){mm+=12;yy--}ms.push(yy+'-'+String(mm).padStart(2,'0'))}
 const d=ms.map(x=>[tot('income',x),tot('expense',x),x]),mx=Math.max(1,...d.flatMap(x=>[x[0],x[1]]));
 return `<svg viewBox="0 0 300 120" width="100%">${d.map((v,i)=>{const h1=v[0]/mx*85,h2=v[1]/mx*85;return `<rect x="${i*50+7}" y="${95-h1}" width="16" height="${h1}" rx="3" fill="var(--inc)"/><rect x="${i*50+26}" y="${95-h2}" width="16" height="${h2}" rx="3" fill="var(--exp)"/><text x="${i*50+25}" y="112" font-size="10" text-anchor="middle" fill="var(--mut)">${new Date(v[2]+'-01T00:00').toLocaleString(undefined,{month:'short'})}</text>`}).join('')}</svg>
 <small><span class="income">■</span> Income &nbsp; <span class="expense">■</span> Expenses</small>`}

/* ---------- views ---------- */
const accName=id=>(S.accounts.find(a=>a.id==id)||{}).name||'Someone else';
const row=t=>`<div class="row" onclick="txForm(${t.id})"><span class="ic">${t.type=='transfer'?'🔁':CE[t.cat]||'📦'}</span><div class="grow"><b>${esc(t.type=='transfer'?'Transfer → '+accName(t.to):t.cat)}</b><small>${esc(t.note||'')}</small></div><b class="expense">−${fmt(t.amount)}</b></div>`;
const irow=i=>`<div class="row" ${i.kind=='inc'?`onclick="incForm(${i.id})"`:''}><span class="ic">${i.kind=='tin'?'🔁':CI[i.cat]||'💰'}</span><div class="grow"><b>${esc(i.cat)}</b><small>${esc(i.date)}${i.month!=monthOf(i.date)?' · for '+mshort(i.month):''}${i.note?' · '+esc(i.note):''}</small></div><b class="income">+${fmt(i.amount)}</b></div>`;
const pc=(a,b)=>b>0?Math.round(a/b*100):0;
const bkNudge=()=>{const b=S.settings.backup;return S.settings.hasData&&(!b||Date.now()-b>30*864e5)?`<div class="warn" onclick="go('set')">💾 ${b?'Your last backup is over 30 days old.':'You have not made a backup yet.'} Tap to back up your data.</div>`:''};
const bcol=p=>p>=100?'var(--exp)':p>=80?'var(--warn)':'var(--inc)';
const hb=r=>r.map(([l,v,t,c])=>{const p=pc(v,t);return `<div style="margin:10px 0"><div style="display:flex;justify-content:space-between;gap:8px"><span>${l}</span><b>${t?p+'%':''}</b></div><div class="bar"><i style="width:${Math.min(100,p)}%;background:${c||'var(--inc)'}"></i></div><small>${fmt(v)}${t?' of '+fmt(t):''}</small></div>`}).join('');
function vDash(){const A=curAcc(),m=S.atx.filter(t=>t.date.startsWith(M)&&t.type=='expense'),inc=inM(M),sp=sumA(m),f=A.f,funds=f.inn;
 const pn=id=>(S.plans.find(p=>p.id==id)||{}).name||'',U=(pl,c)=>sumA(m.filter(t=>t.plan==pl&&t.type=='expense'&&t.cat==c));
 const byPlan=S.plans.map(p=>[p.icon+' '+esc(p.name),sumA(m.filter(t=>t.plan==p.id))]).filter(x=>x[1]>0).sort((a,b)=>b[1]-a[1]);
 const cats=EXP.map(c=>[(CE[c]||'📦')+' '+c,sumA(m.filter(t=>t.cat==c))]).filter(x=>x[1]>0).sort((a,b)=>b[1]-a[1]);
 const src=[...INC,'Transfer in'].map(c=>[(CI[c]||'🔁')+' '+c,sumA(S.inc.filter(i=>i.month==M&&i.cat==c))]).filter(x=>x[1]>0);
 const bp=S.plans.map(p=>{const bs=S.abud.filter(b=>b.plan==p.id),L=bs.reduce((a,b)=>a+b.lim,0),u=bs.reduce((a,b)=>a+U(p.id,b.cat),0);return [p.icon+' '+esc(p.name),u,L,bcol(pc(u,L))]}).filter(x=>x[2]>0);
 const warn=S.abud.filter(b=>U(b.plan,b.cat)>=b.lim*.8).map(b=>`<div class="warn" onclick="switchPlan(${b.plan}).then(()=>go('bud'))">${U(b.plan,b.cat)>=b.lim?'🚨 Over budget':'⚠️ Almost at limit'}: ${esc(pn(b.plan))} · ${CE[b.cat]||''} ${b.cat} — ${pc(U(b.plan,b.cat),b.lim)}%</div>`).join('');
 const money=[['✅ Available',Math.max(A.bal,0)],...S.plans.map(p=>[p.icon+' '+esc(p.name),sumA(m.filter(t=>t.plan==p.id))]).filter(x=>x[1]>0)];
 const extra=[f.carried?fmt(f.carried)+' carried over':'',f.pocket?fmt(f.pocket)+' pocket money':''].filter(Boolean).join(' · ');
 return `${monBar()}<div class="card hero"><small>${esc(A.name)} · available in ${mname(M)}</small><div class="n">${fmt(A.bal)}</div>
 <div class="two"><div><small>Income</small><b>${fmt(inc)}</b></div><div><small>Spent</small><b>${fmt(sp)}</b></div><div><small>Used</small><b>${funds>0?pc(sp,funds)+'%':'—'}</b></div></div>${extra?`<small style="margin-top:8px">Includes ${extra}</small>`:''}</div>${bkNudge()}${warn}
 <div class="card"><h3>Account money</h3><small style="margin-bottom:8px">${pc(A.bal,funds)}% of this month's money (${fmt(funds)}) is still available</small>${donut(money)}</div>
 <div class="card"><h3>This month</h3>${hb([['Spent vs money for the month',sp,funds,bcol(pc(sp,funds))]])}${funds>0?'':'<small>Add income for this month in the Account tab to see this %.</small>'}<h4 style="margin:12px 0 6px">Spending by plan</h4>${donut(byPlan)}</div>
 <div class="card"><h3>Spending by category</h3>${cats.length?hb(cats.map(([l,v])=>[l,v,sp,'var(--pri)'])):'<p class="mut">No spending this month.</p>'}</div>
 ${bp.length?`<div class="card"><h3>Budgets used</h3>${hb(bp)}</div>`:''}
 ${S.agoals.length?`<div class="card"><h3>Goals progress</h3>${hb(S.agoals.map(g=>[g.icon+' '+esc(g.name)+' · '+esc(pn(g.plan)),g.saved,g.target,'var(--pri)']))}</div>`:''}
 <div class="card"><h3>Income by source</h3>${src.length?hb(src.map(([l,v])=>[l,v,inc,'var(--inc)'])):'<p class="mut">No income this month.</p>'}</div>
 <div class="card"><h3>Last 6 months</h3>${bars()}</div>`}
const lst=()=>{const r=S.tx.filter(t=>t.date.startsWith(M)&&(flt=='all'||t.type==flt)&&(!q||(t.cat+' '+(t.note||'')).toLowerCase().includes(q.toLowerCase())));
 if(!r.length)return '<p class="empty">Nothing found.<br>Tap <b>+</b> to add a transaction.</p>';let d='',h='';
 r.forEach(t=>{if(t.date!=d){d=t.date;h+=`<h4>${new Date(d+'T00:00').toLocaleDateString(undefined,{weekday:'short',day:'numeric',month:'short'})}</h4>`}h+=row(t)});return h};
const vAct=()=>`${monBar()}<input placeholder="🔍 Search notes or categories" value="${esc(q)}" oninput="q=this.value;$('#list').innerHTML=lst()">
 <div class="chips sc">${['all','expense','transfer'].map(f=>`<button class="chip ${flt==f?'on':''}" onclick="flt='${f}';render()">${f[0].toUpperCase()+f.slice(1)}</button>`).join('')}</div><div id="list">${lst()}</div>`;
function vBud(){const cats=EXP.filter(c=>c!='Savings'),TL=cats.reduce((s,c)=>s+lim(c),0),TS=cats.reduce((s,c)=>s+spent(c),0);
 return `${monBar()}<h2>Budgets</h2><div class="card"><small>Planned vs spent this month</small><b style="font-size:22px">${fmt(TS)}</b> <span class="mut">of ${fmt(TL)}</span>
 <div class="bar"><i style="width:${TL?Math.min(100,TS/TL*100):0}%;background:${TS>TL&&TL?'var(--exp)':'var(--inc)'}"></i></div></div>
 <p class="mut" style="margin:4px">Tap a category to set its monthly limit.</p>`+cats.map(c=>{const l=lim(c),s=spent(c),p=l?s/l*100:0,col=p>=100?'var(--exp)':p>=80?'var(--warn)':'var(--inc)';
 return `<div class="card" onclick="budForm('${c}')" style="cursor:pointer"><div style="display:flex;justify-content:space-between"><b>${CE[c]} ${c}</b><span>${fmt(s)}${l?' / '+fmt(l):''}</span></div>
 ${l?`<div class="bar"><i style="width:${Math.min(100,p)}%;background:${col}"></i></div><small>${s>l?'Over by '+fmt(s-l):fmt(l-s)+' left'}</small>`:'<small>No limit set</small>'}</div>`}).join('')}
function vGoal(){return `<h2>Savings goals</h2>`+(S.goals.length?S.goals.map(g=>{const p=g.target?Math.min(100,g.saved/g.target*100):0;
 return `<div class="card"><div style="display:flex;justify-content:space-between;align-items:center"><b style="font-size:18px">${g.icon} ${esc(g.name)}</b><button class="chip" onclick="goalForm(${g.id})">Edit</button></div>
 <div class="bar"><i style="width:${p}%"></i></div><div style="display:flex;justify-content:space-between"><span>${fmt(g.saved)}</span><span class="mut">${Math.round(p)}% of ${fmt(g.target)}</span></div>
 <button class="btn" onclick="goalAdd(${g.id})">Add money</button></div>`}).join(''):'<p class="empty">No goals yet.<br>What are you saving for?</p>')+`<button class="btn alt" onclick="goalForm()">New goal</button>`}
function vInsights(){const months=[];let [y,m]=M.split('-').map(Number);for(let i=5;i>=0;i--){let mm=m-i,yy=y;while(mm<1){mm+=12;yy--}months.push(yy+'-'+String(mm).padStart(2,'0'))}
 const rows=months.map(month=>({month,income:sumA(S.inc.filter(i=>i.month==month)),spent:sumA(S.atx.filter(t=>t.type=='expense'&&monthOf(t.date)==month))}));
 const current=rows[rows.length-1],previous=rows[rows.length-2],delta=current.spent-previous.spent;
 const expenses=S.atx.filter(t=>t.type=='expense'&&monthOf(t.date)==M),total=sumA(expenses);
 const cats=EXP.map(cat=>({cat,total:sumA(expenses.filter(t=>t.cat==cat))})).filter(x=>x.total>0).sort((a,b)=>b.total-a.total);
 const budgets=S.abud.filter(b=>b.plan&&S.plans.some(p=>p.id==b.plan));const budgetLimit=sumA(budgets.map(b=>({amount:b.lim})));
 const budgetSpent=sumA(budgets.map(b=>({amount:sumA(expenses.filter(t=>t.plan==b.plan&&t.cat==b.cat))})));
 return `${monBar()}<div class="card hero"><small>PREMIUM FEATURE PREVIEW · ${esc(curAcc().name)}</small><h2 style="margin:6px 0">Monthly insights</h2><p class="mut">Understand your spending patterns over the last six months.</p><div class="two"><div><small>Spent this month</small><b>${fmt(current.spent)}</b></div><div><small>Income this month</small><b>${fmt(current.income)}</b></div></div></div>
 <div class="card"><h3>Compared with last month</h3><b style="font-size:22px;color:${delta>0?'var(--exp)':'var(--inc)'}">${delta>0?'▲ '+fmt(delta):delta<0?'▼ '+fmt(Math.abs(delta)):fmt(0)}</b><p class="mut">${delta>0?'You spent more':delta<0?'You spent less':'Your spending was unchanged'} than ${mname(previous.month)}.</p></div>
 <div class="card"><h3>Spending by category · ${mname(M)}</h3>${cats.length?hb(cats.map(x=>[(CE[x.cat]||'📦')+' '+x.cat,x.total,total,'var(--pri)'])):'<p class="empty">No expenses recorded for this month.</p>'}</div>
 <div class="card"><h3>Budget overview</h3>${budgetLimit?hb([['Budget limits used',budgetSpent,budgetLimit,bcol(pc(budgetSpent,budgetLimit))]]):'<p class="mut">Set budgets to see how your spending compares with your limits.</p>'}</div>
 <div class="card"><h3>Last six months</h3>${rows.map(r=>`<div class="row"><div class="grow"><b>${mname(r.month)}</b><small>Income ${fmt(r.income)}</small></div><b class="expense">${fmt(r.spent)}</b></div>`).join('')}<small>Transfers are excluded from spending totals. This report uses data stored on this device.</small></div>`}
async function addPlan(a){if(a!=S.account){S.account=a;S.plan=0;await api('nav')}planForm()}
async function pickPlan(a,p){S.account=a;S.plan=p;flt='all';q='';if(await api('nav'))toast('Selected '+curPlan().name+' · '+curAcc().name)}
function vAcc(){const A=curAcc(),f=A.f,inc=inM(M),mi=S.inc.filter(i=>i.month==M),other=S.inc.length-mi.length,carry=S.settings.carry;
 return `${monBar()}<h2>Accounts</h2>${S.accounts.map(a=>{const sel=a.id==S.account;return `<div class="card" style="${sel?'border-color:var(--pri)':''}">
 <div class="row" style="border:0;padding:0;margin:0 0 8px" onclick="switchAcc(${a.id})"><span class="ic">${a.icon}</span><div class="grow"><b>${esc(a.name)}</b><small>${fmtC(a.cur,a.bal)} available${sel?' · ✓':''}</small></div><button class="chip" onclick="event.stopPropagation();accForm(${a.id})">Edit</button></div>
 ${S.aplans.filter(p=>p.account==a.id).map(p=>`<div class="row" style="margin-left:14px;${sel&&p.id==S.plan?'border-color:var(--pri)':''}" onclick="pickPlan(${a.id},${p.id})"><span class="ic" style="width:34px;height:34px;font-size:18px">${p.icon}</span><div class="grow"><b>${esc(p.name)}</b></div><b class="expense">−${fmtC(a.cur,p.spent)}</b></div>`).join('')}
 <button class="chip" style="margin:2px 0 0 14px" onclick="addPlan(${a.id})">＋ New plan</button></div>`}).join('')}
 <button class="btn alt" style="margin-bottom:16px" onclick="accForm()">＋ New account</button>
 <h2>${A.icon} ${esc(A.name)}</h2><div class="card hero"><small>Available in ${mname(M)}</small><div class="n">${fmt(A.bal)}</div>
 <div class="two"><div><small>${carry?'Carried + pocket':'Pocket money'}</small><b>${fmt(f.carried+f.pocket)}</b></div><div><small>Income</small><b>${fmt(inc)}</b></div><div><small>Spent</small><b>${fmt(f.spent)}</b></div></div></div>
 <button class="btn" onclick="incForm()">＋ Add income for ${mname(M)}</button><button class="btn alt" onclick="accForm(${A.id})">Edit account · pocket money</button>
 <h4>Income & transfers in · ${mname(M)}</h4>${mi.length?mi.map(irow).join(''):'<p class="empty">No income for this month yet.<br>Tap Add income, or use ‹ › to view another month.</p>'}
 ${other>0?`<small style="text-align:center;margin-top:6px">${other} more income entr${other==1?'y':'ies'} in other months</small>`:''}`}
function render(){$('#main').innerHTML=(tab=='act'||tab=='bud'||tab=='goal'?planBar():'')+({home:vDash,act:vAct,bud:vBud,goal:vGoal,ins:vInsights,acc:vAcc,set:vSet})[tab]();
 const T={home:['📈','Dashboard'],act:['🧾','Activity'],bud:['📊','Budgets'],goal:['🎯','Goals'],ins:['✨','Insights'],acc:['🏦','Account'],set:['⚙️','Settings']};
 $('#nav').innerHTML=Object.entries(T).map(([k,[i,l]])=>`<button class="${k==tab?'on':''}" onclick="go('${k}')"><span>${i}</span>${l}</button>`).join('')}

/* ---------- plans + settings ---------- */
const curPlan=()=>S.plans.find(p=>p.id==S.plan)||{name:'My plan',icon:'📁',cur:'$'};
const planBar=()=>`${tab=='set'?'':`<div class="acclab" onclick="go('acc')"><span>${curAcc().icon}</span><span>Account: <b>${esc(curAcc().name)}</b> · ${fmt(curAcc().bal)} available in ${mshort(M)}</span><span style="margin-left:auto">›</span></div>`}<div class="plans">${S.plans.map(p=>`<button class="pl ${p.id==S.plan?'on':''}" onclick="switchPlan(${p.id})">${p.icon} ${esc(p.name)}</button>`).join('')}<button class="pl add" onclick="planForm()">＋ New plan</button></div>`;
async function switchAcc(id){if(id==S.account)return;S.account=id;S.plan=0;flt='all';q='';if(await api('nav'))toast('Switched to '+curAcc().name)}
async function switchPlan(id){if(id==S.plan)return;const old=S.plan;S.plan=id;flt='all';q='';if(await api('nav'))toast('Switched to '+curPlan().name);else S.plan=old}
const isNative=()=>!!(window.Capacitor&&Capacitor.isNativePlatform&&Capacitor.isNativePlatform());
const isStandalone=()=>navigator.standalone===true||(window.matchMedia&&matchMedia('(display-mode: standalone)').matches);
const isIOS=()=>/iphone|ipad|ipod/i.test(navigator.userAgent)||(navigator.platform=='MacIntel'&&navigator.maxTouchPoints>1);
let deferred=null;
addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferred=e;if(tab=='set'&&S.accounts.length)render()});
addEventListener('appinstalled',()=>{deferred=null;if(tab=='set')render()});
async function installApp(){if(!deferred)return;deferred.prompt();try{await deferred.userChoice}catch(e){}deferred=null;render()}
const instCard=()=>isNative()||isStandalone()?'':`<h4>Install</h4><div class="card">${deferred?'<small style="margin-bottom:6px">Install Money Manager as an app with its own icon. It works offline.</small><button class="btn" onclick="installApp()">Install app</button>':isIOS()?'<small>On iPhone or iPad: tap the Share button in Safari, then <b>Add to Home Screen</b>.</small>':'<small>In Chrome or Edge, use the install icon in the address bar (or the browser menu, then Install) to add this app to your computer or phone.</small>'}</div>`;
async function setCarry(v){if(await api('carry_set',{v}))toast(v?'Leftover money now carries over':'Each month now starts fresh')}
let P={};
function planForm(id){P=id?{...S.plans.find(p=>p.id==id)}:{name:'',icon:'📁',cur:cur()};drawPlan(true)}
function drawPlan(fresh){if(!fresh){P.name=val('pn',P.name);P.cur=val('pc',P.cur)}
 sheet(`<h3>${P.id?'Edit':'New'} plan</h3><input id="pn" placeholder="Plan name (e.g. Personal, Business, Trip)" value="${esc(P.name)}">
 <div class="chips">${PI.map(i=>`<button class="chip ${P.icon==i?'on':''}" onclick="P.icon='${i}';drawPlan()">${i}</button>`).join('')}</div>
 ${P.id?'':'<small style="margin:6px 4px">A new plan starts empty and spends from the account balance.</small>'}
 <button class="btn" onclick="savePlan()">Save plan</button>${P.id&&S.plans.length>1?`<button class="btn ghost" onclick="delPlan(${P.id})">Delete plan</button>`:''}`)}
async function savePlan(){P.name=val('pn',P.name).trim();if(!P.name)return toast('Give the plan a name');closeS();flt='all';q='';if(await api('plan_save',P))toast('Plan "'+P.name+'" saved ✓')}
async function delPlan(id){if(confirm('Delete this plan with its activity, budgets and goals? Its expenses are removed, so that money returns to the account balance.')){closeS();flt='all';q='';if(await api('plan_del',{id}))toast('Plan deleted')}}
const CUR=[['$','USD'],['€','EUR'],['£','GBP'],['¥','JPY'],['₹','INR'],['₦','NGN'],['₱','PHP'],['R','ZAR'],['KSh','KES'],['GH₵','GHS'],['R$','BRL'],['₩','KRW'],['Rs','PKR'],['৳','BDT'],['₫','VND'],['Rp','IDR'],['RM','MYR'],['฿','THB']];
async function setCur(v){v=(v||'').trim();if(!v)return toast('Choose a symbol or type your own');const all=!!(document.getElementById('call')||{}).checked;if(await api('cur_set',{v,all}))toast('Currency is now '+v+(all?' in all accounts':''))}
const vSet=()=>`<h2>Settings</h2><h4>Accounts</h4>${S.accounts.map(a=>`<div class="row" onclick="switchAcc(${a.id})"><span class="ic">${a.icon}</span><div class="grow"><b>${esc(a.name)}</b><small>${fmtC(a.cur,a.bal)} available · pocket ${fmtC(a.cur,a.pocket)}${a.id==S.account?' · active':''}</small></div><button class="chip" onclick="event.stopPropagation();accForm(${a.id})">Edit</button></div>`).join('')}<button class="btn alt" onclick="accForm()">New account</button><small style="margin:6px 4px">Edit changes the name, icon, currency and pocket money. Plans live inside accounts.</small><h4>Plans in ${esc(curAcc().name)}</h4>`+S.plans.map(p=>`<div class="row" onclick="switchPlan(${p.id})"><span class="ic">${p.icon}</span><div class="grow"><b>${esc(p.name)}</b><small>${p.id==S.plan?'Active plan':'Tap to switch'}</small></div>${p.id==S.plan?'<b class="income">✓</b>':''}<button class="chip" onclick="event.stopPropagation();planForm(${p.id})">Edit</button></div>`).join('')+
 `<button class="btn alt" onclick="planForm()">New plan</button><small style="margin:8px 4px">Every plan has its own activity, budgets and goals, and spends from the account balance.</small>
 <h4>Monthly balance</h4><div class="card"><small style="margin-bottom:8px">Pocket money, income and spending each belong to one month. What happens to money that is left over at the end of a month?</small>
 <div class="seg"><button class="${S.settings.carry?'':'on'}" onclick="setCarry(false)">Start fresh</button><button class="${S.settings.carry?'on':''}" onclick="setCarry(true)">Carry over</button></div>
 <small>${S.settings.carry?'Unspent money (and overspending) rolls into the next month.':'Each month only shows the money added for that month. Nothing rolls over.'}</small></div>
 <h4>Currency</h4><div class="card"><small style="margin-bottom:4px">Used in "${esc(curAcc().name)}". Now: <b>${esc(cur())}</b></small>
 <div class="chips">${CUR.map(([c,n])=>`<button class="chip ${c==cur()?'on':''}" data-s="${esc(c)}" onclick="setCur(this.dataset.s)">${esc(c)} ${n}</button>`).join('')}</div>
 <label>Or type your own symbol</label><input id="cc" maxlength="4" placeholder="e.g. USh, ₿, Fr">
 <button class="btn alt" onclick="setCur(val('cc',''))">Use my symbol</button>
 <label style="display:flex;gap:8px;align-items:center;margin-top:10px"><input id="call" type="checkbox" style="width:auto;margin:0">Apply to all my accounts</label></div>
 <h4>Security</h4><div class="card">${S.settings.has_pin?`<small style="margin-bottom:6px">PIN is on. The app asks for it when you open it.</small><button class="btn alt" onclick="lockNow()">Lock now</button><button class="btn alt" onclick="changePin()">Change PIN</button><button class="btn ghost" onclick="removePin()">Remove PIN</button>`:`<small>Add a PIN so only you can open this app.</small><button class="btn" onclick="newPin('',true,false)">Set a PIN</button>`}</div>
 ${instCard()}<h4>About</h4><div class="card"><small>Money Manager v${PAGE_VER} · ${S.accounts.length} account${S.accounts.length==1?'':'s'} · ${DB.plans.length} plans · works offline<br>${S.settings.backup?'Last backup: '+new Date(S.settings.backup).toLocaleDateString():'No backup made yet'}</small>${storeOK?'':'<small style="color:var(--exp);margin-top:6px">⚠️ This browser cannot save data for this file. Use "Share / save backup" before you close it.</small>'}</div>
 <h4>Data</h4><div class="card"><small style="margin-bottom:6px">Download everything in "${esc(curAcc().name)}" (income and all plans) as a spreadsheet file.</small><button class="btn alt" onclick="exportCSV()">Download CSV</button>
 <small style="margin:10px 0 6px">Backup keeps ALL plans. Share it to move your data to another phone or computer.</small>
 <button class="btn alt" onclick="downloadBackup()">Share / save backup</button>${dbRecoveryKey?'<small style="margin:10px 0 6px;color:var(--warn)">A recovery copy of unreadable saved data was preserved. Export it before clearing app data.</small><button class="btn ghost" onclick="downloadRecoveryCopy()">Export recovery copy</button>':''}
 <label class="btn alt" style="display:block;text-align:center">Restore from backup<input type="file" accept=".json,application/json" hidden onchange="restoreBackup(this.files[0],this)"></label></div>`

/* ---------- forms (values are read from the fields at the moment you tap Save) ---------- */
function txForm(id){F=id?{...S.tx.find(t=>t.id==id)}:{type:'expense',amount:'',cat:'Food',to:0,date:defDate(),note:''};drawTx(true)}
function syncTx(){F.amount=val('fa',F.amount);F.note=val('fn',F.note);F.date=val('fd',F.date)||today();const t=val('fto',null);if(t!==null)F.to=+t}
function setType(t){syncTx();if(F.type==t)return;F.type=t;F.cat=t=='expense'?'Food':'Transfer';drawTx(true)}
function drawTx(fresh){if(!fresh)syncTx();const A=curAcc(),others=S.accounts.filter(a=>a.id!=S.account);
 sheet(`<h3>${F.id?'Edit':'New'} transaction</h3><div class="seg">${['expense','transfer'].map(t=>`<button class="${F.type==t?'on '+t:''}" onclick="setType('${t}')">${t[0].toUpperCase()+t.slice(1)}</button>`).join('')}</div>
 <input id="fa" class="big" type="text" inputmode="decimal" autocomplete="off" placeholder="0.00" value="${esc(F.amount)}">
 ${F.type=='expense'?`<div class="chips">${EXP.map(c=>`<button class="chip ${F.cat==c?'on':''}" onclick="F.cat='${c}';drawTx()">${CE[c]} ${c}</button>`).join('')}</div>`:
 `<label>Send to</label><select id="fto">${others.map(a=>`<option value="${a.id}" ${a.id==F.to?'selected':''}>${a.icon} ${esc(a.name)} (${esc(a.cur)})</option>`).join('')}<option value="0" ${!F.to?'selected':''}>Someone else (outside the app)</option></select>`}
 <small style="margin:4px">Comes out of ${esc(A.name)} · ${fmt(A.bal)} available in ${mshort(M)}. Income is added from the Account tab.</small>
 ${F.goal?'<small style="margin:4px;color:var(--warn)">Savings-goal deposit: changing the amount also updates the goal.</small>':''}${F.type=='transfer'&&others.some(a=>a.cur!=A.cur)?'<small style="margin:4px">Transfers between different currencies are not supported yet. Choose an account using the same currency.</small>':''}
 <label>Date</label><input id="fd" type="date" value="${F.date}"><input id="fn" placeholder="Note (optional)" value="${esc(F.note)}">
 <button class="btn" onclick="saveTx()">Save</button>${F.id?`<button class="btn ghost" onclick="delTx(${F.id})">Delete</button>`:''}`)}
async function saveTx(){syncTx();const amt=num(F.amount);if(!(amt>0))return toast('Enter an amount above 0, like 12.50');if(amt>=1e12)return toast('That amount is too large');
 const mo=monthOf(F.date),av=availFor(S.account,mo,F.id);
 if(amt>av&&!confirm('This is more than the '+fmt(av)+' available in '+curAcc().name+' for '+mname(mo)+'. Continue?'))return;
 F.amount=amt;const ty=F.type;closeS();if(!await api('tx_save',F))return;
 toast(`Saved −${fmt(amt)} · ${mshort(mo)} balance ${fmt(availFor(S.account,mo))} ✓`);
 if(ty=='expense'){const l=lim(F.cat),s=spent(F.cat,mo);if(l&&s>l)setTimeout(()=>toast(`⚠️ ${F.cat} is over budget by ${fmt(s-l)}`),1500)}}
async function delTx(id){if(confirm('Delete this transaction?')){closeS();if(await api('tx_del',{id}))toast('Deleted')}}
function budForm(c){sheet(`<h3>${CE[c]} ${c} budget</h3><p class="mut">Spent this month: ${fmt(spent(c))}</p><input id="bl" type="text" inputmode="decimal" autocomplete="off" placeholder="Monthly limit (0 = none)" value="${lim(c)||''}">
 <button class="btn" onclick="saveBud('${c}')">Save budget</button>`)}
async function saveBud(c){const v=num(val('bl',0));closeS();if(await api('budget_set',{cat:c,lim:v}))toast(v>0?'Budget saved ✓':'Budget removed')}
function goalForm(id){G=id?{...S.goals.find(g=>g.id==id)}:{name:'',icon:'🎯',target:''};drawGoal(true)}
function drawGoal(fresh){if(!fresh){G.name=val('gn',G.name);G.target=val('gt',G.target)}
 sheet(`<h3>${G.id?'Edit':'New'} goal</h3><input id="gn" placeholder="Goal name (e.g. New laptop)" value="${esc(G.name)}">
 <input id="gt" type="text" inputmode="decimal" autocomplete="off" placeholder="Target amount" value="${esc(G.target)}"><div class="chips">${GI.map(i=>`<button class="chip ${G.icon==i?'on':''}" onclick="G.icon='${i}';drawGoal()">${i}</button>`).join('')}</div>
 <button class="btn" onclick="saveGoal()">Save goal</button>${G.id?`<button class="btn ghost" onclick="delGoal(${G.id})">Delete goal</button>`:''}`)}
async function saveGoal(){G.name=val('gn',G.name).trim();G.target=num(val('gt',G.target));if(!G.name||!(G.target>0))return toast('Add a name and a target amount');closeS();if(await api('goal_save',G))toast('Goal saved ✓')}
async function delGoal(id){if(confirm('Delete this goal? Past transactions stay.')){closeS();await api('goal_del',{id})}}
function goalAdd(id){const g=S.goals.find(x=>x.id==id);sheet(`<h3>${g.icon} Add to ${esc(g.name)}</h3><p class="mut">Comes out of ${esc(curAcc().name)} (${fmt(availFor(S.account,monthOf(today())))} available this month) and shows in Activity as Savings.</p>
 <input id="ga" class="big" type="text" inputmode="decimal" autocomplete="off" placeholder="0.00"><button class="btn" onclick="doGoal(${id})">Add money</button>`)}
async function doGoal(id){const a=num(val('ga',0));if(!(a>0))return toast('Enter an amount above 0');const av=availFor(S.account,monthOf(today()));if(a>av&&!confirm('More than the '+fmt(av)+' available this month. Continue?'))return;closeS();if(await api('goal_add',{id,amount:a,date:today()}))toast('Nice! Goal updated 🎯')}
let I={},AC={};const AI=['🏦','💵','👛','💳','🏠','💼','🎓','✈️'];
function mpick(id,v){if(!MK.test(v||''))v=M;const[vy,vm]=v.split('-').map(Number),y=new Date().getFullYear(),y0=Math.min(y-6,vy),y1=Math.max(y+4,vy),ys=[];for(let k=y0;k<=y1;k++)ys.push(k);
 const mn=Array.from({length:12},(_,i)=>new Date(2000,i,1).toLocaleString(undefined,{month:'long'}));
 return `<div style="display:flex;gap:8px"><select id="${id}m" aria-label="Month">${mn.map((n,i)=>`<option value="${i+1}" ${i+1==vm?'selected':''}>${n}</option>`).join('')}</select><select id="${id}y" aria-label="Year" style="max-width:120px">${ys.map(k=>`<option ${k==vy?'selected':''}>${k}</option>`).join('')}</select></div>`}
const mget=(id,f)=>{const m=document.getElementById(id+'m'),y=document.getElementById(id+'y');return m&&y?y.value+'-'+String(m.value).padStart(2,'0'):f};
function incForm(id){I=id?{...S.inc.find(i=>i.id==id)}:{amount:'',cat:'Salary',date:today(),month:M,note:''};drawInc(true)}
function syncInc(){I.amount=val('ia',I.amount);I.note=val('in',I.note);I.date=val('idt',I.date)||today();I.month=mget('im',I.month)}
function drawInc(fresh){if(!fresh)syncInc();sheet(`<h3>${I.id?'Edit':'Add'} income</h3><p class="mut">Goes into ${esc(curAcc().name)} and is shared by all its plans.</p>
 <input id="ia" class="big" type="text" inputmode="decimal" autocomplete="off" placeholder="0.00" value="${esc(I.amount)}"><div class="chips">${INC.map(c=>`<button class="chip ${I.cat==c?'on':''}" onclick="I.cat='${c}';drawInc()">${CI[c]} ${c}</button>`).join('')}</div>
 <label>Counts for month</label>${mpick('im',I.month)}
 <small style="margin:2px 4px 8px">${S.settings.carry?'Added to this month, then carried into later months.':'Only adds to the balance of this month, not to any other month.'}</small>
 <label>Date received</label><input id="idt" type="date" value="${I.date}"><input id="in" placeholder="Note (optional)" value="${esc(I.note)}"><button class="btn" onclick="saveInc()">Save income</button>${I.id?`<button class="btn ghost" onclick="delInc(${I.id})">Delete</button>`:''}`)}
async function saveInc(){syncInc();const a=num(I.amount);if(!(a>0))return toast('Enter an amount above 0');I.amount=a;closeS();if(await api('inc_save',I))toast('Income added +'+fmt(a)+' ✓')}
async function delInc(id){if(confirm('Delete this income?')){closeS();if(await api('inc_del',{id}))toast('Deleted')}}
function accForm(id){AC=id?{...S.accounts.find(a=>a.id==id)}:{name:'',icon:'🏦',cur:cur(),pocket:'',pocketMonth:M};drawAcc(true)}
function drawAcc(fresh){if(!fresh){AC.name=val('an',AC.name);AC.pocket=val('ap',AC.pocket);AC.cur=val('ac',AC.cur);AC.pocketMonth=mget('apm',AC.pocketMonth)}
 sheet(`<h3>${AC.id?'Edit':'New'} account</h3><input id="an" placeholder="Account name (e.g. Main, Savings, Business)" value="${esc(AC.name)}">
 <label>Pocket money (the money you have in this account)</label><input id="ap" type="text" inputmode="decimal" autocomplete="off" placeholder="0.00" value="${esc(AC.pocket)}">
 <label>Pocket money counts for month</label>${mpick('apm',AC.pocketMonth)}<small style="margin:2px 4px 8px">${S.settings.carry?'Counted from this month onward.':'Only this month. Add it again (or turn on Carry over in Settings) for other months.'}</small>
 <label>Currency symbol</label><input id="ac" maxlength="4" value="${esc(AC.cur)}"><div class="chips">${AI.map(i=>`<button class="chip ${AC.icon==i?'on':''}" onclick="AC.icon='${i}';drawAcc()">${i}</button>`).join('')}</div>
 ${AC.id?'':'<small style="margin:4px">A first plan called General is created inside it.</small>'}<button class="btn" onclick="saveAcc()">Save account</button>${AC.id&&S.accounts.length>1?`<button class="btn ghost" onclick="delAcc(${AC.id})">Delete account</button>`:''}`)}
async function saveAcc(){AC.name=val('an',AC.name).trim();AC.pocket=num(val('ap',AC.pocket));AC.cur=val('ac',AC.cur).trim()||'$';AC.pocketMonth=mget('apm',AC.pocketMonth);if(!AC.name)return toast('Give the account a name');closeS();flt='all';q='';if(await api('acc_save',AC))toast('Account saved ✓')}
async function delAcc(id){if(confirm('Delete this account with ALL its plans, expenses and income? This cannot be undone.')){closeS();if(await api('acc_del',{id}))toast('Account deleted')}}
function exportCSV(){const pn=id=>(S.plans.find(p=>p.id==id)||{}).name||'';
 const g=v=>{v=String(v??'');return /^[=+\-@\t\r]/.test(v)?"'"+v:v};
 const body=[...S.inc.map(i=>[i.date,i.month,i.kind=='tin'?'transfer in':'income','',i.cat,i.amount,i.note]),...S.atx.map(t=>[t.date,monthOf(t.date),t.type,pn(t.plan),t.cat,-t.amount,t.note])].sort((x,y)=>x[0]<y[0]?1:x[0]>y[0]?-1:0);
 const r=[['Date','For month','Type','Plan','Category','Amount','Note'],...body];
 const csv='\ufeff'+r.map(x=>x.map((v,k)=>'"'+(k==5&&typeof v=='number'?String(v):g(v)).replace(/"/g,'""')+'"').join(',')).join('\r\n');
 saveFile('money-'+curAcc().name.replace(/[^\w]+/g,'_')+'.csv',csv,'text/csv')}
/* ---------- PIN lock (screen lock stored on this device) ---------- */
const sha256=(()=>{const P=[];for(let n=2;P.length<64;n++)if(P.every(p=>n%p))P.push(n);const fr=x=>Math.floor((x-Math.floor(x))*4294967296);
 const K=P.map(p=>fr(Math.cbrt(p))),H0=P.slice(0,8).map(p=>fr(Math.sqrt(p))),te=new TextEncoder(),w=new Uint32Array(64);
 return s=>{const bt=te.encode(s),l=bt.length,n=((l+9+63)>>6)<<6,m=new Uint8Array(n);m.set(bt);m[l]=128;const dv=new DataView(m.buffer);dv.setUint32(n-4,(l*8)>>>0);dv.setUint32(n-8,Math.floor(l*8/4294967296));
  const h=H0.slice();
  for(let o=0;o<n;o+=64){for(let i=0;i<16;i++)w[i]=dv.getUint32(o+i*4);
   for(let i=16;i<64;i++){const x=w[i-15],y=w[i-2];w[i]=(w[i-16]+((x>>>7|x<<25)^(x>>>18|x<<14)^(x>>>3))+w[i-7]+((y>>>17|y<<15)^(y>>>19|y<<13)^(y>>>10)))>>>0}
   let[a,b,c,d,e,f,g,k]=h;
   for(let i=0;i<64;i++){const t1=(k+((e>>>6|e<<26)^(e>>>11|e<<21)^(e>>>25|e<<7))+((e&f)^(~e&g))+K[i]+w[i])>>>0,t2=(((a>>>2|a<<30)^(a>>>13|a<<19)^(a>>>22|a<<10))+((a&b)^(a&c)^(b&c)))>>>0;k=g;g=f;f=e;e=(d+t1)>>>0;d=c;c=b;b=a;a=(t1+t2)>>>0}
   h[0]=(h[0]+a)>>>0;h[1]=(h[1]+b)>>>0;h[2]=(h[2]+c)>>>0;h[3]=(h[3]+d)>>>0;h[4]=(h[4]+e)>>>0;h[5]=(h[5]+f)>>>0;h[6]=(h[6]+g)>>>0;h[7]=(h[7]+k)>>>0}
  return h.map(x=>x.toString(16).padStart(8,'0')).join('')}})();
const pinHash=(pin,salt)=>{let h=sha256(salt+':'+pin);for(let i=0;i<5000;i++)h=sha256(h+salt+pin);return h};
const rnd=()=>Array.from(crypto.getRandomValues(new Uint8Array(12)),x=>x.toString(16).padStart(2,'0')).join('');
const pinOK=p=>DB.pin&&pinHash(p,DB.pin.salt)==DB.pin.hash;
let LK={},hid=0,FAIL={n:0,until:0};
const hideLock=()=>{$('#lock').style.display='none';$('#lock').innerHTML=''};
function lockUI(title,sub,cb,extra){LK={buf:'',title,sub,cb,extra};drawLock()}
function drawLock(){const k=['1','2','3','4','5','6','7','8','9','⌫','0','✓'];$('#lock').style.display='flex';
 $('#lock').innerHTML=`<div class="lk"><div style="font-size:46px">🔐</div><h2>${LK.title}</h2><p class="mut" style="min-height:22px;margin:0 0 14px">${LK.sub}</p>
 <div class="dots">${[0,1,2,3,4,5].map(i=>`<span class="${i<LK.buf.length?'f':''}"></span>`).join('')}</div>
 <div class="pad">${k.map(x=>`<button onclick="pk('${x}')">${x}</button>`).join('')}</div>${LK.extra||''}</div>`}
function pk(x){if(x=='⌫')LK.buf=LK.buf.slice(0,-1);else if(x=='✓'){if(LK.buf.length<4){LK.sub='Use at least 4 digits';return drawLock()}const p=LK.buf;LK.buf='';return LK.cb(p)}else if(LK.buf.length<6)LK.buf+=x;drawLock()}
document.addEventListener('keydown',e=>{if($('#lock').style.display!='flex')return;if(/^\d$/.test(e.key))pk(e.key);else if(e.key=='Backspace')pk('⌫');else if(e.key=='Enter')pk('✓')});
const cancelBtn='<button class="chip" onclick="hideLock()">Cancel</button>';
function askLogin(msg){DB=readDB();lockUI('Welcome back',msg||'Enter your PIN',p=>{
 const w=FAIL.until-Date.now();if(w>0)return askLogin('Too many tries. Wait '+Math.ceil(w/1000)+'s');
 if(pinOK(p)){FAIL.n=0;hideLock();load();return}
 FAIL.n++;if(FAIL.n>=5){FAIL.n=0;FAIL.until=Date.now()+30000;return askLogin('Too many tries. Wait 30s')}askLogin('Wrong PIN. '+(5-FAIL.n)+' tries left')})}
function newPin(cur,cancelable,first,msg){const extra=cancelBtn;
 lockUI('Create a PIN',msg||'Choose 4 to 6 digits',p1=>{lockUI('Confirm PIN','Enter the same PIN again',p2=>{
  if(p1!=p2)return newPin(cur,cancelable,first,"PINs didn't match. Try again");
  DB=readDB();const salt=rnd();DB.pin={salt,hash:pinHash(p1,salt)};writeDB();hideLock();load();toast('PIN saved 🔐')},extra)},extra)}
function askCur(next,msg){DB=readDB();lockUI('Current PIN',msg||'Enter your current PIN',p=>{if(pinOK(p))next(p);else askCur(next,'Wrong PIN')},cancelBtn)}
const changePin=()=>askCur(c=>newPin(c,true,false));
const removePin=()=>askCur(()=>{DB=readDB();DB.pin=null;writeDB();hideLock();load();toast('PIN removed')});
function lockNow(){closeS();DB=readDB();if(DB.pin)askLogin()}
function boot(){DB=readDB();if(!dbWriteBlocked)writeDB();try{if(navigator.storage&&navigator.storage.persist)navigator.storage.persist().catch(()=>{})}catch(e){}if(DB.pin)return askLogin();load();if(dbRecoveryWarning)toast('⚠️ '+dbRecoveryWarning);else if(!storeOK)toast('⚠️ Data cannot be saved here. Use Settings → backup.')}
document.addEventListener('visibilitychange',()=>{if(document.hidden)hid=Date.now();else if(S.settings.has_pin&&hid&&Date.now()-hid>60000)lockNow()});

/* ---------- backup / restore (all plans, one small file) ---------- */
function backupData(){DB=readDB();return JSON.stringify({format:'money-manager-backup',version:2,exported:new Date().toISOString(),carry:!!DB.carry,accounts:DB.accounts,plans:DB.plans,tx:DB.tx,inc:DB.inc,budgets:DB.budgets,goals:DB.goals})}
/* returns true when the file was saved or shared, false otherwise */
async function saveFile(name,data,type){
 const P=window.Capacitor&&Capacitor.Plugins;
 if(isNative()){
  try{if(P&&P.Filesystem&&P.Share){const w=await P.Filesystem.writeFile({path:name,data:btoa(unescape(encodeURIComponent(data))),directory:'CACHE'});await P.Share.share({title:name,url:w.uri,dialogTitle:'Save or share '+name});return true}
   if(navigator.share){await navigator.share({title:name,text:data});return true}}
  catch(e){if(/cancel|abort|dismiss/i.test(String(e&&(e.name||e.message||e))))return false;toast('Could not save the file');return false}
  toast('Saving files is not available here');return false}
 const blob=new Blob([data],{type});
 try{const f=new File([blob],name,{type});if(matchMedia('(pointer:coarse)').matches&&navigator.canShare&&navigator.canShare({files:[f]})){await navigator.share({files:[f],title:name});return true}}catch(e){if(e&&e.name=='AbortError')return false}
 const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),4000);toast('Saved to your downloads');return true}
async function downloadBackup(){if(await saveFile('money-manager-backup-'+today()+'.json',backupData(),'application/json'))api('backup_mark')}
async function downloadRecoveryCopy(){if(!dbRecoveryKey)return toast('No recovery copy is available');let raw;try{raw=localStorage.getItem(dbRecoveryKey)}catch(e){}if(raw==null)return toast('The recovery copy is no longer available');await saveFile('money-manager-recovery-'+today()+'.txt',raw,'text/plain')}
function restoreBackup(file,inp){if(!file)return;const r=new FileReader();r.onload=()=>{let N;
 try{const o=JSON.parse(r.result);if(!o||o.format!='money-manager-backup'||!Array.isArray(o.plans)||!o.plans.length)throw 0;
  N=clean(o.version==2&&Array.isArray(o.accounts)&&o.accounts.length?o:migrate(o))}catch(e){if(inp)inp.value='';return toast('That file is not a valid Money Manager backup')}
 if(inp)inp.value='';
 if(!confirm('Replace ALL data in this app with the backup ('+N.plans.length+' plans, '+N.tx.length+' transactions)?'))return;
 DB=readDB();N.pin=DB.pin;const previous=DB;DB=N;if(!writeDB()){DB=previous;if(inp)inp.value='';return toast('Could not save the restored backup. Existing data was not replaced.')}S.account=0;S.plan=0;load();toast('Backup restored ✓')};r.readAsText(file)}
boot();
document.addEventListener('keydown',e=>{if(e.key=='Escape'&&$('#sheet').style.display=='block')closeS()});
/* Android: hardware back button closes sheets, goes back to the dashboard, then exits */
try{const A=window.Capacitor&&Capacitor.Plugins&&Capacitor.Plugins.App;if(A&&A.addListener)A.addListener('backButton',()=>{
 if($('#lock').style.display=='flex'){if(LK.extra)hideLock();else A.exitApp();return}
 if($('#sheet').style.display=='block')return closeS();if(tab!='home')return go('home');A.exitApp()})}catch(e){}
/* offline support + installable web app (not used inside the native Android wrapper) */
if('serviceWorker' in navigator&&/^https?:$/.test(location.protocol)&&!isNative())addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));
