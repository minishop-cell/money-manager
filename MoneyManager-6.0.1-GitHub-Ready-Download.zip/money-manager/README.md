# Money Manager

An offline money manager: accounts, plans, monthly income, budgets, savings goals, PIN lock, CSV export and backups.
All data stays on your device. There is no server and no account.

One codebase, three ways to install:

| Platform | How |
|---|---|
| **Android** | APK built by GitHub Actions (see below) |
| **Windows / Mac / Linux / Chromebook** | Install from Chrome or Edge as an app (PWA) |
| **iPhone / iPad** | Safari → Share → **Add to Home Screen** (PWA) |

## 1. Put it on GitHub

1. Create a new repository and upload everything in this folder (keep the `.github` folder).
2. **Settings → Pages → Build and deployment → Source: GitHub Actions.**
3. Push to `main`. Two workflows run:
   - **Deploy web app** publishes `www/` to `https://<your-username>.github.io/<repo-name>/`. This is the link you open on PC and iPhone.
   - **Build Android APK** produces the APK (**Actions → the run → Artifacts**).
4. To make a public release with the APK attached:
   ```
   git tag v6.0.0
   git push --tags
   ```
   The APK appears under **Releases**. Bump `version` in `package.json` for each release.

## 2. Install

**Android:** download `MoneyManager-release.apk` (or `-debug.apk`) from Releases, open it, and allow "install unknown apps" for your browser/files app when asked.

**PC:** open your GitHub Pages link in Chrome or Edge, then click the install icon in the address bar (or Settings inside the app → Install). It then runs in its own window and works offline.

**iPhone / iPad:** open the link in **Safari**, tap Share, then **Add to Home Screen**. Installing this way matters: Safari can delete data of sites that are only bookmarked and unused for a week, but not of an installed home-screen app.

A real iOS App Store build needs a Mac, Xcode and a paid Apple developer account, so it is not part of this project. The home-screen install behaves like an app for this kind of tool.

## 3. Sign your APK once (important)

Every GitHub run creates a new random *debug* key. Android refuses to update an app when the signing key changed, so you would have to uninstall first, and **uninstalling deletes your data**. Fix this once with your own key:

```
keytool -genkeypair -v -keystore release.jks -alias moneymanager -keyalg RSA -keysize 2048 -validity 10000
base64 -w0 release.jks        # macOS: base64 -i release.jks
```

Keep `release.jks` and its passwords somewhere safe (if you lose it you cannot update the app). Then add four repository secrets (**Settings → Secrets and variables → Actions**):

| Secret | Value |
|---|---|
| `ANDROID_KEYSTORE_BASE64` | the base64 output above |
| `ANDROID_KEYSTORE_PASSWORD` | keystore password |
| `ANDROID_KEY_ALIAS` | `moneymanager` |
| `ANDROID_KEY_PASSWORD` | key password |

From then on the workflow also builds `MoneyManager-release.apk`, signed with your key, which updates in place. Use that one.

Before your first release, change `appId` in `capacitor.config.json` (for example `io.github.yourname.moneymanager`). It cannot be changed later without becoming a different app.

## 4. How monthly income works

- Every income entry has a **Counts for month** picker. It defaults to the month you are viewing and you can pick any month and year.
- Pocket money (account balance you already had) has the same picker, under **Edit account**.
- Expenses belong to the month of their date.
- The balance shown is for the month you are looking at: money added for that month minus that month's spending. Use the ‹ › arrows (tap the month name to jump back to today).
- **Settings → Monthly balance:**
  - **Start fresh** (default): nothing rolls over, income only reflects in its own month.
  - **Carry over**: unspent money, or overspending, rolls into later months.
- Transfers between your accounts count in the month of the transfer.

When restoring an older Money Manager web-backup format, each income gets the month of its date and pocket money is assigned to the earliest month with data in that account. This app starts with fresh data on a new installation. It does not import the separate Python/Kivy SQLite database automatically.

## 5. Run and test locally

```
npm run serve     # http://localhost:8080  (needs python3)
npm test          # 28 logic/rendering and regression tests, no browser needed
```

Build the APK locally (needs Node 22, JDK 21, Android SDK):
```
npm install && npx cap add android && npx cap sync android
cd android && ./gradlew assembleDebug
```

## 6. Reliability fixes in version 6.0.1

- Impossible calendar dates (for example February 31 and invalid leap days) are rejected by both transaction entry and backup validation.
- Corrupt saved JSON is copied to a recovery key before the app starts fresh. The recovery copy can be exported from Settings; if it cannot safely preserve and clear the damaged data, writes are blocked instead of overwriting the original.
- Outgoing transfers are excluded from spending-category totals, dashboard spending, and expense chart bars. Transfers still affect account balances and remain visible in activity and statements.
- Transfers must have a valid destination account. Transfers between accounts with different currencies are blocked until currency conversion is implemented.
- A failed database write or failed backup restore no longer reports success.
- Added regression tests for these cases.

## 7. What was fixed compared with the single-file version

- Income, pocket money and balances are now per month (above).
- A backup file could inject code through currency/icon/category fields. Restore now rebuilds and validates every record.
- Currency symbols are HTML-escaped; "−$0.00" rounding glitch fixed; all money is rounded to cents.
- The "more than available" warning now checks the month of the transaction and no longer counts an edited expense twice.
- Savings-goal totals now follow their deposit when it is edited or deleted.
- CSV export neutralises spreadsheet formulas (cells starting with `=`, `+`, `-`, `@`), adds a month column and a UTF-8 marker so Excel shows currency symbols.
- Amount, date and size validation in the data layer. Restoring the same backup file twice works.
- Backup reminder (30 days), last-backup date, Escape closes dialogs, Android back button support, requests persistent storage.
- Removed the code that only worked inside Claude's preview.

## 8. Good to know

- **The PIN is a screen lock, not encryption.** Data is stored unencrypted on the device. Use your phone's own lock for real protection.
- Data lives in the app's own storage. Clearing browser data or uninstalling deletes it, so use **Settings → Share / save backup** regularly. Transfers between accounts with different currencies are currently blocked because no exchange-rate conversion is implemented.
- Not tested on physical devices. The automated suite passes, but physical Android testing is still required. After your first APK build, check these on your phone: the layout below the status bar, the Backup/CSV share sheet, and the back button. If something looks off, open an issue.
