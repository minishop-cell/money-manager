# Money Manager 6.0.1 — bug-fix notes

## Fixed in this build

1. **Impossible dates** — transaction entry and backup cleanup now validate the actual calendar date, including leap years, instead of relying on JavaScript date parsing alone.
2. **Corrupt local storage** — unreadable saved data is copied to a `mm_db_recovery_<timestamp>` local-storage key before starting fresh. The preserved recovery copy can be exported from Settings. If preservation or clearing fails, normal writes are blocked so the original data is not silently overwritten.
3. **Transfer reporting** — dashboard spending totals, spending categories, spending by plan, and expense chart bars exclude transfers. Transfers continue to change source/destination balances and appear in activity/statement history.
4. **Transfer integrity** — a transfer must have a valid destination account different from the source account. Transfers between different currencies are blocked until exchange-rate conversion exists.
5. **Persistence feedback** — ordinary data changes and backup restore check whether storage succeeded instead of displaying success after a failed write.
6. **Regression tests** — added checks for impossible dates, missing/invalid transfer destinations, cross-currency transfers, corrupt-storage recovery, and spending totals.

## Test result

Run `node tests/run.js` (or `npm test`) from the project root. Current result: **28 passed, 0 failed**. This is automated logic/rendering coverage, not a substitute for testing the APK on a physical Android device.

## Fresh installation

A new installation starts with a default account and no transactions. The project does not migrate the separate Python/Kivy `pocket_money.db` file. Do not copy that database into this app's storage.

## Remaining limitations

- The PIN is a screen lock, not database encryption.
- Transfers between different currencies are not supported.
- Local data may be lost if app storage is cleared or the app is uninstalled; export a backup regularly.
- Android file sharing, hardware back behavior, and upgrades must still be tested on a real device.
